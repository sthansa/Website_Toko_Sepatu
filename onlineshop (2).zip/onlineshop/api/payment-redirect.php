<?php
require_once __DIR__ . '/../includes/init.php';

$orderId = $_GET['order_id'] ?? '';
$statusCode = $_GET['status_code'] ?? '';
$transactionStatus = $_GET['transaction_status'] ?? '';

if ($orderId) {
    $orderModel = new Order($db);
    $order = $orderModel->getByOrderNumber($orderId);
    
    // Untuk keperluan localhost bypass, kita asumsikan return callback dari midtrans (QRIS/E-Wallet) dsb yang memiliki orderId artinya pembayaran sukses/pending finish.
    // Jika masih pending dan transaction_status nya settlement/capture atau status_code 200, update status ke paid.
    if ($order && $order['status'] === 'pending') {
        $orderModel->updateStatusByOrderNumber($orderId, 'paid');
    }
    
    // Redirect ke halaman orders
    redirect(base_url('orders.php?order_number=' . urlencode($orderId)));
} else {
    redirect(base_url('products.php'));
}
