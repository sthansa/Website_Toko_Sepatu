<?php
/**
 * Webhook / Notification handler untuk Payment Gateway (Midtrans)
 * URL ini harus didaftarkan di dashboard Midtrans sebagai Notification URL
 */
require_once __DIR__ . '/../includes/init.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit;
}

// Jika menggunakan Midtrans, uncomment dan install midtrans/php
/*
require_once __DIR__ . '/../vendor/autoload.php';
\Midtrans\Config::$serverKey = PAYMENT_MIDTRANS_SERVER_KEY;
\Midtrans\Config::$isProduction = PAYMENT_IS_PRODUCTION;

$notification = new \Midtrans\Notification();
$orderNumber = $notification->order_id;
$status = $notification->transaction_status;
$fraud = $notification->fraud_status ?? '';

if (in_array($status, ['capture', 'settlement']) && $fraud !== 'deny') {
    $orderModel = new Order(getDbConnection());
    $order = $orderModel->getByOrderNumber($orderNumber);
    if ($order) {
        $orderModel->updateStatus((int) $order['id'], 'paid');
        $orderModel->updatePaymentReference((int) $order['id'], $notification->transaction_id ?? '');
    }
}
*/

http_response_code(200);
echo 'OK';
