<?php
require_once __DIR__ . '/../includes/init.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $orderNumber = trim($_POST['order_number'] ?? '');
    if ($orderNumber) {
        $orderModel = new Order($db);
        $order = $orderModel->getByOrderNumber($orderNumber);
        
        if ($order && $order['status'] === 'shipped') {
            $orderModel->updateStatusByOrderNumber($orderNumber, 'delivered');
        }
    }
}

redirect(base_url('orders.php?order_number=' . urlencode($orderNumber)));
