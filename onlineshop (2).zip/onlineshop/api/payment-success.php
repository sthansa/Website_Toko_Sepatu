<?php
require_once __DIR__ . '/../includes/init.php';

header("Content-Type: application/json; charset=UTF-8");

$input = json_decode(file_get_contents('php://input'), true);
$orderId = $input['order_id'] ?? '';
$statusCode = $input['status_code'] ?? '';

if ($orderId) {
    $orderModel = new Order($db);
    $order = $orderModel->getByOrderNumber($orderId);
    if ($order && $order['status'] === 'pending') {
        // Update status ke paid
        $orderModel->updateStatusByOrderNumber($orderId, 'paid');
        
        echo json_encode(['success' => true]);
        exit;
    }
}

echo json_encode(['success' => false]);
