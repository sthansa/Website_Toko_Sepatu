<?php
require_once __DIR__ . '/../includes/init.php';
require_once __DIR__ . '/../includes/payment.php';

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['message' => 'Method not allowed']);
    exit;
}

if (!class_exists('Midtrans\Notification')) {
    http_response_code(500);
    echo json_encode(['message' => 'Midtrans SDK not found']);
    exit;
}

\Midtrans\Config::$serverKey = PAYMENT_MIDTRANS_SERVER_KEY ?: '';
\Midtrans\Config::$isProduction = PAYMENT_IS_PRODUCTION;

try {
    $notif = new \Midtrans\Notification();

    $transactionStatus = $notif->transaction_status;
    $paymentType = $notif->payment_type;
    $orderId = $notif->order_id;
    $fraudStatus = $notif->fraud_status;
    $statusCode = $notif->status_code;
    $grossAmount = $notif->gross_amount;
    
    // Verifikasi Signature Key untuk keamanan
    $calculatedSignature = hash("sha512", $orderId . $statusCode . $grossAmount . \Midtrans\Config::$serverKey);
    if ($calculatedSignature !== $notif->signature_key) {
        http_response_code(403);
        echo json_encode(['message' => 'Invalid signature key']);
        exit;
    }

    $status = 'pending';
    
    if ($transactionStatus == 'capture') {
        if ($paymentType == 'credit_card') {
            if ($fraudStatus == 'challenge') {
                $status = 'pending';
            } else {
                $status = 'paid';
            }
        }
    } else if ($transactionStatus == 'settlement') {
        $status = 'paid';
    } else if ($transactionStatus == 'cancel' || $transactionStatus == 'deny' || $transactionStatus == 'expire') {
        $status = 'cancelled';
    } else if ($transactionStatus == 'pending') {
        $status = 'pending';
    }
    
    $orderModel = new Order($db);
    $order = $orderModel->getByOrderNumber($orderId);
    
    if ($order) {
        $orderModel->updateStatusByOrderNumber($orderId, $status);
        echo json_encode(['message' => 'Order status updated successfully', 'order_id' => $orderId, 'status' => $status]);
    } else {
        http_response_code(404);
        echo json_encode(['message' => 'Order not found']);
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['message' => 'Error processing notification: ' . $e->getMessage()]);
}
