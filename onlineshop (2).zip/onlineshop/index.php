<?php
require_once __DIR__ . '/includes/init.php';

$pageTitle = 'Beranda';
$productModel = new Product($db);
$featured = $productModel->getFeatured(8);

require_once __DIR__ . '/includes/header.php';
?>

<section class="hero-section">
    <div class="container text-center position-relative">
        <h1 class="mb-3">Koleksi Sepatu Berkualitas</h1>
        <p class="lead mb-4">Temukan gaya dan kenyamanan untuk setiap langkah Anda. Running, casual, sneakers, dan formal — semua dalam satu toko.</p>
        <a href="<?= base_url('products.php') ?>" class="btn btn-light btn-lg px-4">Lihat Katalog <i class="bi bi-arrow-right ms-2"></i></a>
    </div>
</section>

<div class="container mb-5">
    <h2 class="text-center mb-4 section-title">Produk Unggulan</h2>
    <?php if (empty($featured)): ?>
    <div class="empty-state">
        <i class="bi bi-box-seam d-block"></i>
        <p>Belum ada produk. Silakan tambahkan produk di panel admin.</p>
    </div>
    <?php else: ?>
    <div class="row g-4">
        <?php foreach ($featured as $p): ?>
        <div class="col-6 col-md-4 col-lg-3">
            <div class="card product-card h-100">
                <a href="<?= base_url('product-detail.php?slug=' . e(urlencode($p['slug']))) ?>" class="text-decoration-none text-dark">
                    <img src="<?= $p['image'] ? asset_url('images/' . e($p['image'])) : asset_url('images/placeholder.svg') ?>" class="card-img-top" alt="<?= e($p['name']) ?>">
                    <div class="card-body">
                        <span class="badge category-badge mb-2"><?= e($p['category_name']) ?></span>
                        <h6 class="card-title"><?= e($p['name']) ?></h6>
                        <p class="price mb-0"><?= format_rupiah((float) $p['price']) ?></p>
                    </div>
                </a>
                <div class="card-footer bg-white border-0 pt-0">
                    <a href="<?= base_url('cart-add.php?id=' . $p['id']) ?>" class="btn btn-primary btn-sm w-100">Tambah ke Keranjang</a>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <div class="text-center mt-4">
        <a href="<?= base_url('products.php') ?>" class="btn btn-outline-primary">Lihat Semua Produk</a>
    </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
