<?php
require_once __DIR__ . '/includes/init.php';

$id = isset($_POST['product_id']) ? (int) $_POST['product_id'] : (isset($_GET['id']) ? (int) $_GET['id'] : 0);
$quantity = isset($_POST['quantity']) ? max(1, (int) $_POST['quantity']) : 1;
$size = isset($_POST['size']) ? trim($_POST['size']) : null;

if ($id <= 0) {
    redirect(base_url('products.php'));
}

$productModel = new Product($db);
$product = $productModel->getById($id);
if (!$product || !(int) $product['is_active']) {
    flash('error', 'Produk tidak ditemukan.');
    redirect(base_url('products.php'));
}

$qty = min($quantity, (int) $product['stock']);
Cart::add($id, $qty, $size ?: null);
flash('success', 'Produk ditambahkan ke keranjang.');
$redirect = $_SERVER['HTTP_REFERER'] ?? base_url('cart.php');
redirect($redirect);
?>
