<?php
/**
 * Model Pesanan
 */

class Order
{
    private PDO $db;

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    public function create(array $orderData, array $items): int
    {
        $this->db->beginTransaction();
        try {
            $stmt = $this->db->prepare('INSERT INTO orders (order_number, customer_email, customer_name, customer_phone, shipping_address, subtotal, shipping_cost, total, status, payment_method, snap_token, notes) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
            $stmt->execute([
                $orderData['order_number'],
                $orderData['customer_email'],
                $orderData['customer_name'],
                $orderData['customer_phone'],
                $orderData['shipping_address'],
                $orderData['subtotal'],
                $orderData['shipping_cost'],
                $orderData['total'],
                'pending',
                $orderData['payment_method'] ?? null,
                $orderData['snap_token'] ?? null,
                $orderData['notes'] ?? null
            ]);
            $orderId = (int) $this->db->lastInsertId();

            $itemStmt = $this->db->prepare('INSERT INTO order_items (order_id, product_id, product_name, price, quantity, size, subtotal) VALUES (?, ?, ?, ?, ?, ?, ?)');
            foreach ($items as $item) {
                $itemStmt->execute([
                    $orderId,
                    $item['product_id'],
                    $item['product_name'],
                    $item['price'],
                    $item['quantity'],
                    $item['size'] ?? null,
                    $item['subtotal']
                ]);
            }
            $this->db->commit();
            return $orderId;
        } catch (Exception $e) {
            $this->db->rollBack();
            throw $e;
        }
    }

    public function getById(int $id): ?array
    {
        $stmt = $this->db->prepare('SELECT * FROM orders WHERE id = ?');
        $stmt->execute([$id]);
        $order = $stmt->fetch();
        if (!$order) return null;
        $order['items'] = $this->getItems($id);
        return $order;
    }

    public function getByOrderNumber(string $orderNumber): ?array
    {
        $stmt = $this->db->prepare('SELECT * FROM orders WHERE order_number = ?');
        $stmt->execute([$orderNumber]);
        $order = $stmt->fetch();
        if (!$order) return null;
        $order['items'] = $this->getItems((int) $order['id']);
        return $order;
    }

    public function getItems(int $orderId): array
    {
        $stmt = $this->db->prepare('SELECT * FROM order_items WHERE order_id = ?');
        $stmt->execute([$orderId]);
        return $stmt->fetchAll();
    }

    public function getAll(string $orderBy = 'created_at DESC'): array
    {
        $allowed = ['created_at DESC', 'created_at ASC', 'total DESC', 'status'];
        if (!in_array($orderBy, $allowed)) $orderBy = 'created_at DESC';
        $stmt = $this->db->query("SELECT * FROM orders ORDER BY $orderBy");
        return $stmt->fetchAll();
    }

    public function getDetailedReport(int $limit = 20): array
    {
        $query = 'SELECT o.id, o.order_number, o.customer_name, o.customer_email, o.status, o.created_at, o.payment_method, 
                         i.product_name, i.quantity, i.price, i.subtotal 
                  FROM orders o 
                  JOIN order_items i ON o.id = i.order_id 
                  WHERE o.status IN (\'paid\',\'processing\',\'shipped\',\'delivered\',\'completed\')
                  ORDER BY o.created_at DESC LIMIT ' . (int)$limit;
        $stmt = $this->db->query($query);
        return $stmt->fetchAll();
    }

    public function updateStatus(int $id, string $status): bool
    {
        $stmt = $this->db->prepare('UPDATE orders SET status = ?, updated_at = NOW() WHERE id = ?');
        return $stmt->execute([$status, $id]);
    }

    public function updateStatusByOrderNumber(string $orderNumber, string $status): bool
    {
        $stmt = $this->db->prepare('UPDATE orders SET status = ?, updated_at = NOW() WHERE order_number = ?');
        return $stmt->execute([$status, $orderNumber]);
    }

    public function updatePaymentReference(int $id, string $ref): bool
    {
        $stmt = $this->db->prepare('UPDATE orders SET payment_reference = ?, updated_at = NOW() WHERE id = ?');
        return $stmt->execute([$ref, $id]);
    }

    public function updateTrackingNumber(int $id, string $trackingNumber): bool
    {
        $stmt = $this->db->prepare('UPDATE orders SET tracking_number = ?, updated_at = NOW() WHERE id = ?');
        return $stmt->execute([$trackingNumber, $id]);
    }

    public function getByEmail(string $email): array
    {
        $stmt = $this->db->prepare('SELECT * FROM orders WHERE customer_email = ? ORDER BY created_at DESC');
        $stmt->execute([$email]);
        return $stmt->fetchAll();
    }

    public function delete(int $id): bool
    {
        $stmt = $this->db->prepare('DELETE FROM orders WHERE id = ?');
        return $stmt->execute([$id]);
    }
}
