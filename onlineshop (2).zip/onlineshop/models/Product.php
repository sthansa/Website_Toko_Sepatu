<?php
/**
 * Model Produk
 */

class Product
{
    private PDO $db;

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    public function getAll(bool $activeOnly = true): array
    {
        $sql = 'SELECT p.*, c.name AS category_name, c.slug AS category_slug 
                FROM products p 
                JOIN categories c ON p.category_id = c.id';
        if ($activeOnly) {
            $sql .= ' WHERE p.is_active = 1';
        }
        $sql .= ' ORDER BY p.created_at DESC';
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll();
    }

    public function getByCategory(int $categoryId, bool $activeOnly = true): array
    {
        $sql = 'SELECT p.*, c.name AS category_name FROM products p 
                JOIN categories c ON p.category_id = c.id 
                WHERE p.category_id = ?';
        if ($activeOnly) {
            $sql .= ' AND p.is_active = 1';
        }
        $sql .= ' ORDER BY p.name';
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$categoryId]);
        return $stmt->fetchAll();
    }

    public function getById(int $id): ?array
    {
        $stmt = $this->db->prepare('SELECT p.*, c.name AS category_name, c.slug AS category_slug 
            FROM products p JOIN categories c ON p.category_id = c.id WHERE p.id = ?');
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public function getBySlug(string $slug): ?array
    {
        $stmt = $this->db->prepare('SELECT p.*, c.name AS category_name, c.slug AS category_slug 
            FROM products p JOIN categories c ON p.category_id = c.id WHERE p.slug = ? AND p.is_active = 1');
        $stmt->execute([$slug]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public function getFeatured(int $limit = 6): array
    {
        $stmt = $this->db->prepare('SELECT p.*, c.name AS category_name FROM products p 
            JOIN categories c ON p.category_id = c.id 
            WHERE p.is_active = 1 ORDER BY p.created_at DESC LIMIT ?');
        $stmt->bindValue(1, $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function search(string $query, bool $activeOnly = true): array
    {
        $sql = 'SELECT p.*, c.name AS category_name FROM products p 
                JOIN categories c ON p.category_id = c.id 
                WHERE (p.name LIKE ? OR p.description LIKE ?)';
        if ($activeOnly) {
            $sql .= ' AND p.is_active = 1';
        }
        $sql .= ' ORDER BY p.name';
        $term = '%' . $query . '%';
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$term, $term]);
        return $stmt->fetchAll();
    }

    public function updateStock(int $productId, int $quantity): bool
    {
        $stmt = $this->db->prepare('UPDATE products SET stock = stock - ? WHERE id = ? AND stock >= ?');
        return $stmt->execute([$quantity, $productId, $quantity]);
    }

    public function create(array $data): int
    {
        $stmt = $this->db->prepare('INSERT INTO products (category_id, name, slug, description, price, stock, image, is_active) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
        $stmt->execute([
            $data['category_id'],
            $data['name'],
            $data['slug'],
            $data['description'] ?? '',
            $data['price'],
            $data['stock'] ?? 0,
            $data['image'] ?? null,
            $data['is_active'] ?? 1
        ]);
        return (int) $this->db->lastInsertId();
    }

    public function update(int $id, array $data): bool
    {
        $stmt = $this->db->prepare('UPDATE products SET category_id=?, name=?, slug=?, description=?, price=?, stock=?, image=?, is_active=?, updated_at=NOW() WHERE id=?');
        return $stmt->execute([
            $data['category_id'],
            $data['name'],
            $data['slug'],
            $data['description'] ?? '',
            $data['price'],
            $data['stock'] ?? 0,
            $data['image'] ?? null,
            $data['is_active'] ?? 1,
            $id
        ]);
    }

    public function delete(int $id): bool
    {
        $stmt = $this->db->prepare('DELETE FROM products WHERE id = ?');
        return $stmt->execute([$id]);
    }
}
