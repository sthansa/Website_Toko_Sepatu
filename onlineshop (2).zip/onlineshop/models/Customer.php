<?php
/**
 * Model Pelanggan
 */

class Customer
{
    private PDO $db;

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    public function getByEmail(string $email): ?array
    {
        $stmt = $this->db->prepare('SELECT * FROM customers WHERE email = ?');
        $stmt->execute([$email]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public function getById(int $id): ?array
    {
        $stmt = $this->db->prepare('SELECT * FROM customers WHERE id = ?');
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public function getTotalCount(): int
    {
        $stmt = $this->db->query('SELECT COUNT(*) FROM customers');
        return (int) $stmt->fetchColumn();
    }

    public function create(array $data): int
    {
        $stmt = $this->db->prepare('INSERT INTO customers (email, password_hash, name, phone, address) VALUES (?, ?, ?, ?, ?)');
        $stmt->execute([
            $data['email'],
            $data['password_hash'],
            $data['name'],
            $data['phone'] ?? null,
            $data['address'] ?? null
        ]);
        return (int) $this->db->lastInsertId();
    }

    public function update(int $id, array $data): bool
    {
        $stmt = $this->db->prepare('UPDATE customers SET name=?, phone=?, address=? WHERE id=?');
        return $stmt->execute([
            $data['name'],
            $data['phone'] ?? null,
            $data['address'] ?? null,
            $id
        ]);
    }
}
