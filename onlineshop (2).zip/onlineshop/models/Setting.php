<?php
/**
 * Model Pengaturan Website
 */

class Setting
{
    private PDO $db;

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    public function get(string $key): ?string
    {
        $stmt = $this->db->prepare('SELECT value FROM settings WHERE `key` = ?');
        $stmt->execute([$key]);
        $row = $stmt->fetch();
        return $row ? (string) $row['value'] : null;
    }

    public function set(string $key, string $value): bool
    {
        $stmt = $this->db->prepare('INSERT INTO settings (`key`, value) VALUES (?, ?) ON DUPLICATE KEY UPDATE value = VALUES(value)');
        return $stmt->execute([$key, $value]);
    }

    public function getAll(): array
    {
        $stmt = $this->db->query('SELECT * FROM settings ORDER BY `key`');
        $rows = $stmt->fetchAll();
        $out = [];
        foreach ($rows as $r) {
            $out[$r['key']] = $r['value'];
        }
        return $out;
    }
}
