<?php
/**
 * Keranjang belanja (session-based)
 */

class Cart
{
    private const SESSION_KEY = 'cart_items';

    public static function get(): array
    {
        return $_SESSION[self::SESSION_KEY] ?? [];
    }

    public static function add(int $productId, int $quantity = 1, ?string $size = null): void
    {
        if (!isset($_SESSION[self::SESSION_KEY])) {
            $_SESSION[self::SESSION_KEY] = [];
        }
        $key = $productId . '_' . ($size ?? '');
        if (isset($_SESSION[self::SESSION_KEY][$key])) {
            $_SESSION[self::SESSION_KEY][$key]['quantity'] += $quantity;
        } else {
            $_SESSION[self::SESSION_KEY][$key] = [
                'product_id' => $productId,
                'quantity'   => $quantity,
                'size'       => $size
            ];
        }
    }

    public static function update(string $key, int $quantity): void
    {
        if (isset($_SESSION[self::SESSION_KEY][$key])) {
            if ($quantity <= 0) {
                unset($_SESSION[self::SESSION_KEY][$key]);
            } else {
                $_SESSION[self::SESSION_KEY][$key]['quantity'] = $quantity;
            }
        }
    }

    public static function remove(string $key): void
    {
        unset($_SESSION[self::SESSION_KEY][$key]);
    }

    public static function clear(): void
    {
        $_SESSION[self::SESSION_KEY] = [];
    }

    public static function count(): int
    {
        $items = self::get();
        $total = 0;
        foreach ($items as $item) {
            $total += $item['quantity'];
        }
        return $total;
    }
}
