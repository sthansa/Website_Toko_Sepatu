<?php
require_once __DIR__ . '/includes/init.php';

$key = $_GET['key'] ?? '';
if ($key !== '' && array_key_exists($key, Cart::get())) {
    Cart::remove($key);
    flash('success', 'Item dihapus dari keranjang.');
}
redirect(base_url('cart.php'));
?>
