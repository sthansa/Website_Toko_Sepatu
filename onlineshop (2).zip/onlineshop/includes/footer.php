    </main>
    <footer class="site-footer">
        <div class="container">
            <div class="row g-4">
                <div class="col-md-4">
                    <h5 class="fw-bold"><i class="bi bi-shoe-sneaker me-2"></i><?= e(APP_NAME) ?></h5>
                    <p class="footer-desc">Toko sepatu online terpercaya. Kualitas premium, harga terjangkau.</p>
                </div>
                <div class="col-md-2">
                    <h6 class="footer-heading">Navigasi</h6>
                    <ul class="list-unstyled footer-links">
                        <li><a href="<?= base_url() ?>">Beranda</a></li>
                        <li><a href="<?= base_url('products.php') ?>">Katalog</a></li>
                        <li><a href="<?= base_url('cart.php') ?>">Keranjang</a></li>
                        <li><a href="<?= base_url('orders.php') ?>">Cek Pesanan</a></li>
                    </ul>
                </div>
                <div class="col-md-2">
                    <h6 class="footer-heading">Bantuan</h6>
                    <ul class="list-unstyled footer-links">
                        <li><a href="#">Cara Belanja</a></li>
                        <li><a href="#">Pengiriman</a></li>
                        <li><a href="#">Kontak</a></li>
                    </ul>
                </div>
                <div class="col-md-4 text-md-end">
                    <h6 class="footer-heading">Ikuti Kami</h6>
                    <div class="footer-social">
                        <a href="#" class="footer-social-link"><i class="bi bi-instagram"></i></a>
                        <a href="#" class="footer-social-link"><i class="bi bi-facebook"></i></a>
                        <a href="#" class="footer-social-link"><i class="bi bi-twitter-x"></i></a>
                    </div>
                </div>
            </div>
            <hr class="footer-divider">
            <p class="footer-copy">&copy; <?= date('Y') ?> <?= e(APP_NAME) ?>. All rights reserved.</p>
        </div>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?= asset_url('js/main.js') ?>"></script>
    <?php if (isset($extraScripts)): foreach ((array)$extraScripts as $src): ?>
    <script src="<?= e($src) ?>"></script>
    <?php endforeach; endif; ?>
</body>
</html>
