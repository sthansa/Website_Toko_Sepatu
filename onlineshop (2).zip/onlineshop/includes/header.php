<?php
if (!isset($pageTitle)) $pageTitle = APP_NAME;
$cartCount = class_exists('Cart') ? Cart::count() : 0;
$isCustomerLoggedIn = !empty($_SESSION['customer_id']);
$customerName = $_SESSION['customer_name'] ?? 'Pelanggan';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle) ?> - <?= e(APP_NAME) ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="<?= asset_url('css/style.css') ?>" rel="stylesheet">
</head>
<body class="d-flex flex-column min-vh-100">
    <nav class="navbar navbar-expand-lg navbar-main sticky-top">
        <div class="container">
            <a class="navbar-brand" href="<?= base_url() ?>">
                <i class="bi bi-shoe-sneaker"></i> <?= e(APP_NAME) ?>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMain">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarMain">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item"><a class="nav-link" href="<?= base_url() ?>">Beranda</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= base_url('products.php') ?>">Katalog</a></li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">Kategori</a>
                        <ul class="dropdown-menu dropdown-menu-dark">
                            <?php foreach ($categories ?? [] as $cat): ?>
                            <li><a class="dropdown-item" href="<?= base_url('products.php?category=' . e($cat['id'])) ?>"><?= e($cat['name']) ?></a></li>
                            <?php endforeach; ?>
                        </ul>
                    </li>
                </ul>
                <div class="d-flex align-items-center gap-2">
                    <a class="btn btn-nav-cart position-relative" href="<?= base_url('cart.php') ?>">
                        <i class="bi bi-cart3"></i> Keranjang
                        <?php if ($cartCount > 0): ?>
                        <span class="cart-badge"><?= $cartCount ?></span>
                        <?php endif; ?>
                    </a>
                    <?php if ($isCustomerLoggedIn): ?>
                    <div class="dropdown">
                        <a class="btn btn-nav-account dropdown-toggle" href="#" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle"></i> <?= e($customerName) ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="<?= base_url('customer/dashboard.php') ?>"><i class="bi bi-grid me-2"></i>Dashboard</a></li>
                            <li><a class="dropdown-item" href="<?= base_url('customer/orders.php') ?>"><i class="bi bi-box-seam me-2"></i>Pesanan Saya</a></li>
                            <li><a class="dropdown-item" href="<?= base_url('customer/profile.php') ?>"><i class="bi bi-person me-2"></i>Profil</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="<?= base_url('auth/logout.php') ?>"><i class="bi bi-box-arrow-right me-2"></i>Keluar</a></li>
                        </ul>
                    </div>
                    <?php else: ?>
                    <a class="btn btn-nav-account" href="<?= base_url('auth/login.php') ?>"><i class="bi bi-person"></i> Masuk</a>
                    <a class="btn btn-nav-register" href="<?= base_url('auth/register.php') ?>">Daftar</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>
    <main class="flex-grow-1">
