<?php
/**
 * Bootstrap aplikasi - load config & autoload
 */

session_start();

$composerAutoload = __DIR__ . '/../vendor/autoload.php';
if (file_exists($composerAutoload)) {
    require_once $composerAutoload;
}

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/../models/Product.php';
require_once __DIR__ . '/../models/Category.php';
require_once __DIR__ . '/../models/Order.php';
require_once __DIR__ . '/../models/Cart.php';
require_once __DIR__ . '/../models/Customer.php';
require_once __DIR__ . '/../models/AdminUser.php';

$db = getDbConnection();
$categoryModel = new Category($db);
try {
    $categories = $categoryModel->getAll();
} catch (PDOException $e) {
    $categories = [];
    define('DB_SETUP_REQUIRED', true);
    $uri = $_SERVER['REQUEST_URI'] ?? '';
    if (strpos($uri, 'setup-required') === false && strpos($uri, 'api/') === false) {
        header('Location: ' . rtrim(APP_URL, '/') . '/setup-required.php');
        exit;
    }
}
