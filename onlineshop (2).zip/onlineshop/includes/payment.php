<?php
/**
 * Integrasi Payment Gateway (Midtrans)
 * Untuk production: set MIDTRANS_SERVER_KEY dan MIDTRANS_CLIENT_KEY di environment
 */

function create_midtrans_snap_token(array $orderData): ?string {
    if (!PAYMENT_MIDTRANS_SERVER_KEY) {
        return null; // Demo mode - no real payment
    }
    if (!class_exists('Midtrans\Snap')) {
        throw new Exception("Midtrans SDK is not loaded. Please run composer install.");
    }
    \Midtrans\Config::$serverKey = PAYMENT_MIDTRANS_SERVER_KEY;
    \Midtrans\Config::$isProduction = PAYMENT_IS_PRODUCTION;
    // Bypass local SSL issues on Laragon
    \Midtrans\Config::$curlOptions = [CURLOPT_SSL_VERIFYPEER => false];
    
    $params = [
        'transaction_details' => [
            'order_id' => $orderData['order_number'],
            'gross_amount' => (int) $orderData['total'],
        ],
        'customer_details' => [
            'first_name' => $orderData['customer_name'],
            'email' => $orderData['customer_email'],
            'phone' => $orderData['customer_phone'],
        ],
        'callbacks' => [
            'finish' => base_url('api/payment-redirect.php'),
            'unfinish' => base_url('orders.php'),
            'error' => base_url('orders.php')
        ],
    ];
    try {
        return \Midtrans\Snap::getSnapToken($params);
    } catch (Exception $e) {
        throw $e;
    }
}

function get_midtrans_client_key(): string {
    return PAYMENT_MIDTRANS_CLIENT_KEY ?: '';
}
