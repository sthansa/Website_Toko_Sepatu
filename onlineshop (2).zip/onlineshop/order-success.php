<?php
require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/payment.php';

$orderId = $_SESSION['last_order_id'] ?? null;
$orderNumber = $_SESSION['last_order_number'] ?? null;

if (!$orderId || !$orderNumber) {
    redirect(base_url());
}

$orderModel = new Order($db);
$order = $orderModel->getById($orderId);
if (!$order) {
    unset($_SESSION['last_order_id'], $_SESSION['last_order_number']);
    redirect(base_url());
}

$pageTitle = 'Pesanan Berhasil';
require_once __DIR__ . '/includes/header.php';
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card border-0 shadow summary-card text-center py-5">
                <div class="card-body">
                    <div class="text-success mb-3"><i class="bi bi-check-circle-fill" style="font-size: 4rem;"></i></div>
                    <h1 class="h3 mb-2">Terima kasih! Pesanan Anda berhasil.</h1>
                    <p class="text-muted mb-4">No. Pesanan: <strong><?= e($orderNumber) ?></strong></p>
                    <p class="mb-4">Kami akan mengirimkan konfirmasi pembayaran ke <strong><?= e($order['customer_email']) ?></strong>. Silakan lakukan pembayaran sesuai instruksi yang dikirim.</p>
                    <hr class="my-4">
                    <h5 class="mb-3">Detail Pesanan</h5>
                    <div class="table-responsive text-start">
                        <table class="table">
                            <thead>
                                <tr><th>Produk</th><th>Qty</th><th class="text-end">Subtotal</th></tr>
                            </thead>
                            <tbody>
                                <?php foreach ($order['items'] as $item): ?>
                                <tr>
                                    <td><?= e($item['product_name']) ?></td>
                                    <td><?= (int) $item['quantity'] ?></td>
                                    <td class="text-end"><?= format_rupiah((float) $item['subtotal']) ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <p class="d-flex justify-content-between mb-1"><span>Subtotal</span><span><?= format_rupiah((float) $order['subtotal']) ?></span></p>
                    <p class="d-flex justify-content-between mb-1"><span>Ongkir</span><span><?= format_rupiah((float) $order['shipping_cost']) ?></span></p>
                    <p class="d-flex justify-content-between fw-bold"><span>Total</span><span><?= format_rupiah((float) $order['total']) ?></span></p>
                    <div class="mt-4">
                        <?php if ($order['status'] === 'pending' && !empty($order['snap_token'])): ?>
                            <button id="pay-button" class="btn btn-warning me-2">Bayar Sekarang</button>
                        <?php endif; ?>
                        <a href="<?= base_url('orders.php?order_number=' . urlencode($orderNumber)) ?>" class="btn btn-primary me-2">Cek Status Pesanan</a>
                        <a href="<?= base_url('products.php') ?>" class="btn btn-outline-primary">Lanjut Belanja</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
unset($_SESSION['last_order_id'], $_SESSION['last_order_number']);
$isProduction = PAYMENT_IS_PRODUCTION;
$snapJsUrl = $isProduction ? 'https://app.midtrans.com/snap/snap.js' : 'https://app.sandbox.midtrans.com/snap/snap.js';
$clientKey = get_midtrans_client_key();
?>
<?php if (!empty($order['snap_token'])): ?>
<script src="<?= $snapJsUrl ?>" data-client-key="<?= e($clientKey) ?>"></script>
<script>
document.getElementById('pay-button')?.addEventListener('click', function () {
    window.snap.pay('<?= e($order['snap_token']) ?>', {
        onSuccess: function(result){ 
            fetch('<?= base_url('api/payment-success.php') ?>', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ order_id: result.order_id, status_code: result.status_code })
            }).then(() => window.location.reload());
        },
        onPending: function(result){
            fetch('<?= base_url('api/payment-success.php') ?>', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ order_id: result.order_id, status_code: result.status_code })
            }).then(() => window.location.reload());
        },
        onError: function(result){ alert("Payment failed!"); }
    });
});
</script>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
