<?php
require_once __DIR__ . '/includes/init.php';

$productModel = new Product($db);
$categoryId = isset($_GET['category']) ? (int) $_GET['category'] : null;
$search = isset($_GET['q']) ? trim($_GET['q']) : '';

if ($search !== '') {
    $products = $productModel->search($search);
} elseif ($categoryId) {
    $products = $productModel->getByCategory($categoryId);
} else {
    $products = $productModel->getAll();
}

$pageTitle = $search ? 'Hasil: ' . e($search) : 'Katalog Produk';
require_once __DIR__ . '/includes/header.php';
?>

<div class="container py-4">
    <h1 class="mb-4 section-title"><?= $pageTitle ?></h1>

    <!-- Filter & Search -->
    <div class="row mb-4">
        <div class="col-md-6">
            <form method="get" class="d-flex gap-2">
                <input type="text" name="q" class="form-control" placeholder="Cari produk..." value="<?= e($search) ?>">
                <button type="submit" class="btn btn-primary"><i class="bi bi-search"></i></button>
            </form>
        </div>
        <div class="col-md-6 text-md-end mt-2 mt-md-0">
            <div class="btn-group">
                <a href="<?= base_url('products.php') ?>" class="btn btn-outline-primary btn-sm">Semua</a>
                <?php foreach ($categories as $cat): ?>
                <a href="<?= base_url('products.php?category=' . $cat['id']) ?>" class="btn btn-outline-primary btn-sm"><?= e($cat['name']) ?></a>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <?php if (empty($products)): ?>
    <div class="empty-state">
        <i class="bi bi-search d-block"></i>
        <p>Tidak ada produk ditemukan.</p>
        <a href="<?= base_url('products.php') ?>" class="btn btn-primary">Lihat Semua</a>
    </div>
    <?php else: ?>
    <div class="row g-4">
        <?php foreach ($products as $p): ?>
        <div class="col-6 col-md-4 col-lg-3">
            <div class="card product-card h-100">
                <a href="<?= base_url('product-detail.php?slug=' . e(urlencode($p['slug']))) ?>" class="text-decoration-none text-dark">
                    <img src="<?= $p['image'] ? asset_url('images/' . e($p['image'])) : asset_url('images/placeholder.svg') ?>" class="card-img-top" alt="<?= e($p['name']) ?>">
                    <div class="card-body">
                        <span class="badge category-badge mb-2"><?= e($p['category_name']) ?></span>
                        <h6 class="card-title"><?= e($p['name']) ?></h6>
                        <p class="price mb-0"><?= format_rupiah((float) $p['price']) ?></p>
                    </div>
                </a>
                <div class="card-footer bg-white border-0 pt-0">
                    <a href="<?= base_url('cart-add.php?id=' . $p['id']) ?>" class="btn btn-primary btn-sm w-100">Tambah ke Keranjang</a>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
