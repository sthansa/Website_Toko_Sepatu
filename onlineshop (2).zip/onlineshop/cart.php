<?php
require_once __DIR__ . '/includes/init.php';

$cartItems = Cart::get();
$productModel = new Product($db);
$cartWithProducts = [];
$subtotal = 0;

foreach ($cartItems as $key => $item) {
    $product = $productModel->getById((int) $item['product_id']);
    if (!$product) continue;
    $qty = (int) $item['quantity'];
    $price = (float) $product['price'];
    $itemSubtotal = $price * $qty;
    $subtotal += $itemSubtotal;
    $cartWithProducts[$key] = [
        'key' => $key,
        'product' => $product,
        'quantity' => $qty,
        'size' => $item['size'] ?? null,
        'subtotal' => $itemSubtotal,
    ];
}

$pageTitle = 'Keranjang Belanja';
require_once __DIR__ . '/includes/header.php';

$successMsg = get_flash('success');
$errorMsg = get_flash('error');
?>

<div class="container py-4">
    <h1 class="mb-4 section-title">Keranjang Belanja</h1>

    <?php if ($successMsg): ?>
    <div class="alert alert-success alert-dismissible fade show"><?= e($successMsg) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>
    <?php if ($errorMsg): ?>
    <div class="alert alert-danger alert-dismissible fade show"><?= e($errorMsg) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <?php if (empty($cartWithProducts)): ?>
    <div class="empty-state">
        <i class="bi bi-cart-x d-block"></i>
        <p>Keranjang Anda kosong.</p>
        <a href="<?= base_url('products.php') ?>" class="btn btn-primary">Belanja Sekarang</a>
    </div>
    <?php else: ?>
    <div class="row">
        <div class="col-lg-8">
            <div class="card summary-card">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead>
                            <tr>
                                <th>Produk</th>
                                <th>Harga</th>
                                <th>Jumlah</th>
                                <th>Subtotal</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($cartWithProducts as $row): ?>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center gap-3">
                                        <img src="<?= $row['product']['image'] ? asset_url('images/' . e($row['product']['image'])) : asset_url('images/placeholder.svg') ?>" alt="" class="cart-item-img">
                                        <div>
                                            <strong><?= e($row['product']['name']) ?></strong>
                                            <?php if ($row['size']): ?><br><span class="text-muted small">Ukuran: <?= e($row['size']) ?></span><?php endif; ?>
                                        </div>
                                    </div>
                                </td>
                                <td><?= format_rupiah($row['product']['price']) ?></td>
                                <td>
                                    <form action="<?= base_url('cart-update.php') ?>" method="post" class="d-inline">
                                        <input type="hidden" name="key" value="<?= e($row['key']) ?>">
                                        <input type="number" name="quantity" value="<?= $row['quantity'] ?>" min="1" max="<?= (int)$row['product']['stock'] ?>" class="form-control form-control-sm qty-input d-inline-block" style="width: 70px;">
                                    </form>
                                </td>
                                <td><strong><?= format_rupiah($row['subtotal']) ?></strong></td>
                                <td>
                                    <a href="<?= base_url('cart-remove.php?key=' . urlencode($row['key'])) ?>" class="btn btn-outline-danger btn-sm" data-confirm-remove title="Hapus"><i class="bi bi-trash"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-lg-4 mt-4 mt-lg-0">
            <div class="card summary-card p-4">
                <h5 class="mb-3">Ringkasan</h5>
                <p class="d-flex justify-content-between mb-2"><span>Subtotal</span><span><?= format_rupiah($subtotal) ?></span></p>
                <hr>
                <p class="d-flex justify-content-between fw-bold mb-4"><span>Total</span><span><?= format_rupiah($subtotal) ?></span></p>
                <a href="<?= base_url('checkout.php') ?>" class="btn btn-primary btn-lg w-100">Checkout</a>
                <a href="<?= base_url('products.php') ?>" class="btn btn-outline-primary w-100 mt-2">Lanjut Belanja</a>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
