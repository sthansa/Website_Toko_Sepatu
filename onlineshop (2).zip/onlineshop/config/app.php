<?php
/**
 * Konfigurasi Aplikasi
 */

define('APP_NAME', 'ShoeStore');
define('APP_URL', 'http://localhost/onlineshop');
define('APP_TIMEZONE', 'Asia/Jakarta');

// Payment Gateway - Midtrans (untuk production set ke true)
define('PAYMENT_MIDTRANS_SERVER_KEY', 'Mid-server-7PYj8UATkncYgTcU_fEH8b7A');
define('PAYMENT_MIDTRANS_CLIENT_KEY', 'Mid-client-H8zopgevBldxeJQh');
define('PAYMENT_IS_PRODUCTION', false);

date_default_timezone_set(APP_TIMEZONE);

// Helper base URL
function base_url(string $path = ''): string {
    return rtrim(APP_URL, '/') . '/' . ltrim($path, '/');
}

function asset_url(string $path): string {
    $v = '3'; // ubah angka ini untuk refresh cache CSS/JS
    return base_url('assets/' . ltrim($path, '/')) . (strpos($path, '.css') !== false || strpos($path, '.js') !== false ? '?v=' . $v : '');
}
