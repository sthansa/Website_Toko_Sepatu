# ShoeStore – Online Shop Sepatu

Website toko online sepatu dengan Bootstrap 5, PHP native (tanpa framework), dan fitur e-commerce lengkap: katalog, detail produk, keranjang, checkout, manajemen pesanan, dan integrasi payment gateway.

## Fitur

- **Katalog produk** – Filter kategori, pencarian
- **Detail produk** – Deskripsi, pilihan ukuran, stok
- **Keranjang belanja** – Tambah/edit/hapus item, ringkasan
- **Checkout** – Form data pengiriman, pilihan metode pembayaran
- **Manajemen pesanan** – Cek status via no. pesanan atau email
- **Panel admin** – Login, kelola produk (CRUD), kelola pesanan (ubah status)
- **Payment gateway** – Siap integrasi Midtrans (transfer bank, e-wallet, dll.)

## Persyaratan

- PHP 7.4+ (atau 8.x)
- MySQL 5.7+ / MariaDB
- Web server (Apache/Nginx) atau Laragon/XAMPP

## Instalasi

1. **Clone atau copy** project ke folder web (misalnya `laragon/www/onlineshop`).

2. **Database**
   - Buat database MySQL, lalu import schema:
   ```bash
   mysql -u root -p < database/schema.sql
   ```
   - Atau buka phpMyAdmin, buat database `onlineshop_shoes`, lalu import file `database/schema.sql`.

3. **Konfigurasi**
   - Edit `config/database.php` jika perlu (host, nama DB, user, password).
   - Edit `config/app.php`: sesuaikan `APP_URL` dengan URL situs Anda (mis. `http://localhost/onlineshop`).

4. **Akses**
   - Toko: `http://localhost/onlineshop/`
   - Admin: `http://localhost/onlineshop/admin/`  
     Login default: **admin** / **password** (ganti di production).

## Struktur Folder

```
onlineshop/
├── admin/           # Panel admin (login, produk, pesanan)
├── api/             # Payment notification (webhook)
├── assets/
│   ├── css/
│   ├── js/
│   └── images/      # Gambar produk & placeholder
├── config/          # database.php, app.php
├── database/        # schema.sql
├── includes/        # init, header, footer, functions, payment
├── models/          # Product, Category, Order, Cart
├── index.php        # Beranda
├── products.php     # Katalog
├── product-detail.php
├── cart.php, cart-add.php, cart-update.php, cart-remove.php
├── checkout.php
├── order-success.php
└── orders.php       # Cek pesanan (customer)
```

## Integrasi Payment Gateway (Midtrans)

1. Daftar di [Midtrans](https://midtrans.com), ambil **Server Key** dan **Client Key** (sandbox/production).

2. Set environment variable (atau edit di `config/app.php`):
   - `MIDTRANS_SERVER_KEY`
   - `MIDTRANS_CLIENT_KEY`

3. Untuk production, set `PAYMENT_IS_PRODUCTION` ke `true` di `config/app.php`.

4. Install SDK Midtrans (opsional, untuk Snap/notification):
   ```bash
   composer require midtrans/midtrans-php
   ```
   Lalu load `vendor/autoload.php` di `includes/init.php` atau di `api/payment-notification.php`.

5. Di dashboard Midtrans, set **Notification URL** ke:
   `https://domain-anda.com/onlineshop/api/payment-notification.php`

6. File `includes/payment.php` berisi helper untuk Snap token; `api/payment-notification.php` untuk update status pesanan setelah pembayaran.

Tanpa konfigurasi Midtrans, checkout tetap berjalan; pesanan dibuat dengan status "pending" dan bisa diubah manual di admin.

## Gambar Produk

- Sample data di `schema.sql` memakai path seperti `products/nama-produk.jpg`.
- Letakkan file gambar di `assets/images/products/` atau sesuaikan path di database.
- Jika gambar tidak ada, situs memakai `assets/images/placeholder.svg`.

## Pengembangan

- **Menambah metode pembayaran lain**: extend `includes/payment.php` dan form di `checkout.php`.
- **Upload gambar produk**: tambah form upload di `admin/product-form.php` dan simpan path ke kolom `image`.
- **Email notifikasi**: tambah kirim email setelah order/create di `checkout.php` dan saat status diubah di admin.

## Lisensi

MIT (atau sesuaikan dengan kebutuhan Anda).
