<?php
require_once __DIR__ . '/includes/init.php';

$key = $_POST['key'] ?? '';
$quantity = isset($_POST['quantity']) ? (int) $_POST['quantity'] : 0;

if ($key !== '' && array_key_exists($key, Cart::get())) {
    Cart::update($key, $quantity);
}
redirect(base_url('cart.php'));
?>
