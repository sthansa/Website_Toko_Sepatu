<?php
/**
 * Tampilkan ketika database/tabel belum di-setup
 */
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/app.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Setup Database - <?= htmlspecialchars(APP_NAME) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light min-vh-100 d-flex align-items-center">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6">
                <div class="card shadow border-0">
                    <div class="card-body p-5 text-center">
                        <div class="text-warning mb-3">
                            <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" fill="currentColor" class="bi bi-database-exclamation" viewBox="0 0 16 16">
                                <path d="M12.096 6.223a.5.5 0 0 0-.964 0l-.91 1.747-.918-.695a.5.5 0 0 0-.292-.913l-1.59.36a.5.5 0 0 0-.364.596l.408 1.653-.816.489a.5.5 0 0 0 .227.861l1.268.378c.034.01.066.024.098.042l.604.251a.5.5 0 0 0 .371-.122l.803-.806.807.806a.5.5 0 0 0 .37.122l.605-.25a.5.5 0 0 0 .098-.042l1.268-.378a.5.5 0 0 0 .227-.86l-.815-.49.408-1.654a.5.5 0 0 0-.364-.596l-1.59-.36a.5.5 0 0 0-.292.913l-.918.695-.91-1.747Z"/>
                                <path d="M2.5 15a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5ZM4.094 0a.5.5 0 0 0-.5.5v1.382a.5.5 0 0 0 .276.447l1.052.525a.5.5 0 0 0 .217.086l.792.113V4.5A.5.5 0 0 0 7.5 5h1a.5.5 0 0 0 .5-.5V2.553l.792-.113a.5.5 0 0 0 .217-.086l1.052-.525A.5.5 0 0 0 10.906 1.882V.5a.5.5 0 0 0-.5-.5h-6a.5.5 0 0 0-.5.5v1.382a.5.5 0 0 0 .276.447l1.052.525a.5.5 0 0 0 .217.086l.792.113V4.5A.5.5 0 0 0 6.5 5h1a.5.5 0 0 0 .5-.5V2.553l.792-.113a.5.5 0 0 0 .217-.086l1.052-.525A.5.5 0 0 0 10.906 1.882V.5a.5.5 0 0 0-.5-.5h-6Z"/>
                            </svg>
                        </div>
                        <h1 class="h4 mb-3">Database Belum Di-setup</h1>
                        <p class="text-muted mb-4">Tabel database belum ada. Jalankan file SQL berikut di MySQL (phpMyAdmin atau CLI) untuk membuat database dan tabel:</p>
                        <code class="d-block bg-dark text-light p-3 rounded text-start mb-4">database/schema.sql</code>
                        <ol class="text-start text-muted small mb-4">
                            <li>Buka phpMyAdmin atau MySQL client</li>
                            <li>Import file <strong>database/schema.sql</strong> dari folder project ini</li>
                            <li>Pastikan konfigurasi di <strong>config/database.php</strong> sesuai (nama DB: <code><?= htmlspecialchars(DB_NAME) ?></code> — sama dengan di schema.sql)</li>
                            <li>Refresh halaman ini</li>
                        </ol>
                        <a href="<?= htmlspecialchars(APP_URL) ?>/" class="btn btn-primary">Coba Lagi</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
