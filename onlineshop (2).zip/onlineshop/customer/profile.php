<?php
require_once __DIR__ . '/../includes/init.php';

if (empty($_SESSION['customer_id'])) {
    redirect(base_url('auth/login.php'));
}

$customerModel = new Customer($db);
$customer = $customerModel->getById((int) $_SESSION['customer_id']);
if (!$customer) {
    redirect(base_url('auth/logout.php'));
}

$success = '';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    if (!$name) $error = 'Nama wajib diisi.';
    else {
        $customerModel->update((int) $customer['id'], ['name' => $name, 'phone' => $phone, 'address' => $address]);
        $_SESSION['customer_name'] = $name;
        $customer = $customerModel->getById((int) $customer['id']);
        $success = 'Profil berhasil diperbarui.';
    }
}

$pageTitle = 'Profil Saya';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle) ?> - <?= e(APP_NAME) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="<?= asset_url('css/style.css') ?>" rel="stylesheet">
</head>
<body class="customer-dashboard">
    <?php include __DIR__ . '/nav.php'; ?>
    <div class="dashboard-content">
        <div class="container py-4">
            <h1 class="dashboard-title mb-4">Profil Saya</h1>
            <?php if ($success): ?>
            <div class="alert alert-success"><?= e($success) ?></div>
            <?php endif; ?>
            <?php if ($error): ?>
            <div class="alert alert-danger"><?= e($error) ?></div>
            <?php endif; ?>
            <div class="card dashboard-card">
                <div class="card-body">
                    <form method="post">
                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="text" class="form-control" value="<?= e($customer['email']) ?>" disabled>
                            <small class="text-muted">Email tidak dapat diubah.</small>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Nama Lengkap *</label>
                            <input type="text" name="name" class="form-control" required value="<?= e($customer['name']) ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">No. HP</label>
                            <input type="tel" name="phone" class="form-control" value="<?= e($customer['phone'] ?? '') ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Alamat</label>
                            <textarea name="address" class="form-control" rows="3"><?= e($customer['address'] ?? '') ?></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
