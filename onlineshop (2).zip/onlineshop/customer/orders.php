<?php
require_once __DIR__ . '/../includes/init.php';

if (empty($_SESSION['customer_id'])) {
    redirect(base_url('auth/login.php'));
}

$customerModel = new Customer($db);
$orderModel = new Order($db);
$customer = $customerModel->getById((int) $_SESSION['customer_id']);
$orders = $customer ? $orderModel->getByEmail($customer['email']) : [];

$statusLabels = [
    'pending' => 'Menunggu Pembayaran',
    'paid' => 'Sudah Dibayar',
    'processing' => 'Diproses',
    'shipped' => 'Dikirim',
    'delivered' => 'Sampai',
    'cancelled' => 'Dibatalkan',
];

$pageTitle = 'Pesanan Saya';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle) ?> - <?= e(APP_NAME) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="<?= asset_url('css/style.css') ?>" rel="stylesheet">
</head>
<body class="customer-dashboard">
    <?php include __DIR__ . '/nav.php'; ?>
    <div class="dashboard-content">
        <div class="container py-4">
            <h1 class="dashboard-title mb-4">Pesanan Saya</h1>
            <?php if (empty($orders)): ?>
            <div class="card dashboard-card">
                <div class="card-body text-center py-5">
                    <i class="bi bi-box-seam display-4 text-muted"></i>
                    <p class="mt-3 text-muted">Belum ada pesanan.</p>
                    <a href="<?= base_url('products.php') ?>" class="btn btn-primary">Mulai Belanja</a>
                </div>
            </div>
            <?php else: ?>
            <div class="card dashboard-card">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th>No. Pesanan</th>
                                <th>Tanggal</th>
                                <th>Total</th>
                                <th>Status</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($orders as $o): ?>
                            <tr>
                                <td><?= e($o['order_number']) ?></td>
                                <td><?= date('d M Y H:i', strtotime($o['created_at'])) ?></td>
                                <td><?= format_rupiah((float)$o['total']) ?></td>
                                <td><span class="badge badge-status-<?= e($o['status']) ?>"><?= $statusLabels[$o['status']] ?? $o['status'] ?></span></td>
                                <td><a href="<?= base_url('orders.php?order_number=' . urlencode($o['order_number'])) ?>" class="btn btn-sm btn-outline-primary">Detail</a></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
