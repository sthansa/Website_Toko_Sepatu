<nav class="customer-nav">
    <div class="container d-flex align-items-center justify-content-between">
        <a class="customer-nav-brand" href="<?= base_url() ?>"><i class="bi bi-shoe-sneaker"></i> <?= e(APP_NAME) ?></a>
        <button class="customer-nav-toggler d-lg-none" type="button" data-bs-toggle="collapse" data-bs-target="#customerNavMenu">
            <i class="bi bi-list"></i>
        </button>
        <div class="customer-nav-menu collapse" id="customerNavMenu">
            <a href="dashboard.php"><i class="bi bi-grid me-1"></i>Dashboard</a>
            <a href="orders.php"><i class="bi bi-box-seam me-1"></i>Pesanan</a>
            <a href="profile.php"><i class="bi bi-person me-1"></i>Profil</a>
            <a href="<?= base_url('products.php') ?>"><i class="bi bi-shop me-1"></i>Belanja</a>
            <a href="<?= base_url('cart.php') ?>"><i class="bi bi-cart3 me-1"></i>Keranjang</a>
            <a href="<?= base_url('auth/logout.php') ?>" class="text-danger"><i class="bi bi-box-arrow-right me-1"></i>Keluar</a>
        </div>
    </div>
</nav>
