<?php
require_once __DIR__ . '/../includes/init.php';

if (empty($_SESSION['customer_id'])) {
    redirect(base_url('auth/login.php'));
}

$customerModel = new Customer($db);
$orderModel = new Order($db);
$customer = $customerModel->getById((int) $_SESSION['customer_id']);
$orders = $customer ? $orderModel->getByEmail($customer['email']) : [];
$recentOrders = array_slice($orders, 0, 5);

$statusLabels = [
    'pending' => 'Menunggu Pembayaran',
    'paid' => 'Sudah Dibayar',
    'processing' => 'Diproses',
    'shipped' => 'Dikirim',
    'delivered' => 'Sampai',
    'cancelled' => 'Dibatalkan',
];

$pageTitle = 'Dashboard Saya';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle) ?> - <?= e(APP_NAME) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="<?= asset_url('css/style.css') ?>" rel="stylesheet">
</head>
<body class="customer-dashboard">
    <?php include __DIR__ . '/nav.php'; ?>
    <div class="dashboard-content">
        <div class="container py-4">
            <h1 class="dashboard-title mb-4">Halo, <?= e($customer['name'] ?? 'Pelanggan') ?>!</h1>
            <div class="row g-4">
                <div class="col-lg-4">
                    <div class="card dashboard-card">
                        <div class="card-body">
                            <div class="d-flex align-items-center gap-3">
                                <div class="dashboard-icon bg-primary"><i class="bi bi-person"></i></div>
                                <div>
                                    <h6 class="text-muted mb-0">Profil</h6>
                                    <p class="mb-0 fw-bold"><?= e($customer['name']) ?></p>
                                    <small class="text-muted"><?= e($customer['email']) ?></small>
                                </div>
                            </div>
                            <a href="profile.php" class="btn btn-outline-primary btn-sm mt-3 w-100">Edit Profil</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card dashboard-card">
                        <div class="card-body">
                            <div class="d-flex align-items-center gap-3">
                                <div class="dashboard-icon bg-success"><i class="bi bi-box-seam"></i></div>
                                <div>
                                    <h6 class="text-muted mb-0">Total Pesanan</h6>
                                    <p class="mb-0 fw-bold fs-4"><?= count($orders) ?></p>
                                </div>
                            </div>
                            <a href="orders.php" class="btn btn-outline-primary btn-sm mt-3 w-100">Lihat Semua</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card dashboard-card">
                        <div class="card-body">
                            <div class="d-flex align-items-center gap-3">
                                <div class="dashboard-icon bg-warning"><i class="bi bi-cart3"></i></div>
                                <div>
                                    <h6 class="text-muted mb-0">Keranjang</h6>
                                    <p class="mb-0 fw-bold">Lanjut belanja</p>
                                </div>
                            </div>
                            <a href="<?= base_url('products.php') ?>" class="btn btn-outline-primary btn-sm mt-3 w-100">Belanja Sekarang</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card dashboard-card mt-4">
                <div class="card-header">
                    <h5 class="mb-0">Pesanan Terbaru</h5>
                    <a href="orders.php" class="btn btn-sm btn-outline-primary">Semua</a>
                </div>
                <div class="card-body">
                    <?php if (empty($recentOrders)): ?>
                    <p class="text-muted mb-0">Belum ada pesanan. <a href="<?= base_url('products.php') ?>">Mulai belanja</a></p>
                    <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>No. Pesanan</th>
                                    <th>Tanggal</th>
                                    <th>Total</th>
                                    <th>Status</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recentOrders as $o): ?>
                                <tr>
                                    <td><?= e($o['order_number']) ?></td>
                                    <td><?= date('d M Y', strtotime($o['created_at'])) ?></td>
                                    <td><?= format_rupiah((float)$o['total']) ?></td>
                                    <td><span class="badge badge-status-<?= e($o['status']) ?>"><?= $statusLabels[$o['status']] ?? $o['status'] ?></span></td>
                                    <td><a href="<?= base_url('orders.php?order_number=' . urlencode($o['order_number'])) ?>" class="btn btn-sm btn-outline-primary">Detail</a></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
