<?php
require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/payment.php';

$orderNumber = trim($_GET['order_number'] ?? '');
$email = trim($_GET['email'] ?? '');

$orderDetail = null;
$orders = [];

if ($orderNumber) {
    $orderModel = new Order($db);
    $orderDetail = $orderModel->getByOrderNumber($orderNumber);
}

if ($email) {
    $orderModel = new Order($db);
    $orders = $orderModel->getByEmail($email);
}

$pageTitle = 'Cek Pesanan';
require_once __DIR__ . '/includes/header.php';

$statusLabels = [
    'pending' => 'Menunggu Pembayaran',
    'paid' => 'Sudah Dibayar',
    'processing' => 'Diproses',
    'shipped' => 'Dikirim',
    'delivered' => 'Sampai',
    'cancelled' => 'Dibatalkan',
];
?>

<div class="container py-4">
    <h1 class="mb-4 section-title">Cek Pesanan</h1>

    <div class="card summary-card mb-4">
        <div class="card-body">
            <form method="get" class="row g-2">
                <div class="col-md-4">
                    <input type="text" name="order_number" class="form-control" placeholder="No. Pesanan (contoh: ORD-20240306-ABC123)" value="<?= e($orderNumber) ?>">
                </div>
                <div class="col-md-4">
                    <input type="email" name="email" class="form-control" placeholder="Email pemesan" value="<?= e($email) ?>">
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">Cari</button>
                </div>
            </form>
            <p class="small text-muted mt-2 mb-0">Isi no. pesanan atau email untuk melihat status pesanan.</p>
        </div>
    </div>

    <?php if ($orderDetail): ?>
    <div class="card summary-card mb-4">
        <div class="card-header bg-white">
            <h5 class="mb-0">Pesanan <?= e($orderDetail['order_number']) ?></h5>
        </div>
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <p class="mb-0"><strong>Status:</strong> <span class="badge badge-status-<?= e($orderDetail['status']) ?>"><?= $statusLabels[$orderDetail['status']] ?? $orderDetail['status'] ?></span></p>
                <?php if (in_array($orderDetail['status'], ['paid', 'processing', 'shipped', 'delivered'])): ?>
                <a href="<?= base_url('invoice.php?order_number=' . urlencode($orderDetail['order_number'])) ?>" target="_blank" class="btn btn-sm btn-outline-primary"><i class="bi bi-printer"></i> Cetak / Download Nota</a>
                <?php endif; ?>
            </div>
            <p class="mb-2"><strong>Tanggal:</strong> <?= date('d M Y H:i', strtotime($orderDetail['created_at'])) ?></p>
            <p class="mb-2"><strong>Total:</strong> <?= format_rupiah((float) $orderDetail['total']) ?></p>
            <table class="table table-sm mt-3">
                <thead><tr><th>Produk</th><th>Qty</th><th class="text-end">Subtotal</th></tr></thead>
                <tbody>
                    <?php foreach ($orderDetail['items'] as $item): ?>
                    <tr>
                        <td><?= e($item['product_name']) ?></td>
                        <td><?= (int) $item['quantity'] ?></td>
                        <td class="text-end"><?= format_rupiah((float) $item['subtotal']) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php if ($orderDetail['status'] === 'pending' && !empty($orderDetail['snap_token'])): ?>
            <div class="mt-4">
                <button id="pay-button" class="btn btn-warning w-100"><i class="bi bi-wallet2 me-1"></i>Bayar Sekarang</button>
            </div>
            <?php endif; ?>
            
            <?php if ($orderDetail['status'] === 'shipped'): ?>
            <div class="mt-4">
                <form method="post" action="<?= base_url('api/order-receive.php') ?>" onsubmit="return confirm('Apakah Anda yakin telah menerima pesanan ini dengan baik?');">
                    <input type="hidden" name="order_number" value="<?= e($orderDetail['order_number']) ?>">
                    <button type="submit" class="btn btn-success w-100"><i class="bi bi-box-seam me-1"></i>Pesanan Diterima</button>
                </form>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

    <?php if ($email && !$orderNumber && !empty($orders)): ?>
    <h5 class="mb-3">Riwayat pesanan untuk <?= e($email) ?></h5>
    <div class="card summary-card">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>No. Pesanan</th>
                        <th>Tanggal</th>
                        <th>Total</th>
                        <th>Status</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orders as $o): ?>
                    <tr>
                        <td><?= e($o['order_number']) ?></td>
                        <td><?= date('d M Y', strtotime($o['created_at'])) ?></td>
                        <td><?= format_rupiah((float) $o['total']) ?></td>
                        <td><span class="badge badge-status-<?= e($o['status']) ?>"><?= $statusLabels[$o['status']] ?? $o['status'] ?></span></td>
                        <td><a href="?order_number=<?= urlencode($o['order_number']) ?>" class="btn btn-sm btn-outline-primary">Detail</a></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>

    <?php if (($orderNumber && !$orderDetail) || ($email && empty($orders) && !$orderDetail)): ?>
    <div class="alert alert-warning">Pesanan tidak ditemukan. Periksa no. pesanan atau email.</div>
    <?php endif; ?>
</div>

<?php
$isProduction = PAYMENT_IS_PRODUCTION;
$snapJsUrl = $isProduction ? 'https://app.midtrans.com/snap/snap.js' : 'https://app.sandbox.midtrans.com/snap/snap.js';
$clientKey = get_midtrans_client_key();
?>
<?php if ($orderDetail && !empty($orderDetail['snap_token'])): ?>
<script src="<?= $snapJsUrl ?>" data-client-key="<?= e($clientKey) ?>"></script>
<script>
document.getElementById('pay-button')?.addEventListener('click', function () {
    window.snap.pay('<?= e($orderDetail['snap_token']) ?>', {
        onSuccess: function(result){ 
            fetch('<?= base_url('api/payment-success.php') ?>', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ order_id: result.order_id, status_code: result.status_code })
            }).then(() => window.location.reload());
        },
        onPending: function(result){
            fetch('<?= base_url('api/payment-success.php') ?>', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ order_id: result.order_id, status_code: result.status_code })
            }).then(() => window.location.reload());
        },
        onError: function(result){ alert("Payment failed!"); }
    });
});
</script>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
