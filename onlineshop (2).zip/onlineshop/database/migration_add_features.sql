-- Jalankan jika database sudah ada (tanpa re-import penuh)
-- Menambah kolom dan tabel untuk fitur admin lengkap
USE `schema`;

-- Tambah kolom di orders (abaikan error "Duplicate column" jika sudah ada)
ALTER TABLE orders ADD COLUMN payment_proof VARCHAR(255) DEFAULT NULL;
ALTER TABLE orders ADD COLUMN tracking_number VARCHAR(100) DEFAULT NULL;

-- Buat tabel settings jika belum ada
CREATE TABLE IF NOT EXISTS settings (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `key` VARCHAR(100) NOT NULL UNIQUE,
    `value` TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

INSERT IGNORE INTO settings (`key`, `value`) VALUES
('store_name', 'ShoeStore'),
('store_description', 'Toko sepatu online terpercaya'),
('store_phone', ''),
('store_address', ''),
('store_logo', ''),
('payment_info', 'Transfer ke BCA 1234567890 a.n. Toko.');
