-- ============================================================
-- DATABASE ONLINE SHOP SEPATU - SATU FILE UNTUK phpMyAdmin
-- ============================================================
-- Cara pakai: Buka phpMyAdmin → Import → Pilih file ini → Go
-- File ini akan membuat database + semua tabel + data awal
-- Nama database: schema
-- Admin default: email=admin@onlineshop.com, password=password
-- ============================================================

CREATE DATABASE IF NOT EXISTS `schema` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `schema`;

-- Hapus tabel jika ada (urutan sesuai foreign key)
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS customers;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS admin_users;
DROP TABLE IF EXISTS settings;
SET FOREIGN_KEY_CHECKS = 1;

-- Kategori produk
CREATE TABLE categories (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Produk (sepatu)
CREATE TABLE products (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    category_id INT UNSIGNED NOT NULL,
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(12, 2) NOT NULL,
    stock INT UNSIGNED NOT NULL DEFAULT 0,
    image VARCHAR(255) DEFAULT NULL,
    images JSON DEFAULT NULL COMMENT 'Array path gambar tambahan',
    size_chart TEXT,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY slug (slug),
    KEY category_id (category_id),
    KEY is_active (is_active),
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE RESTRICT
);

-- Pelanggan (untuk checkout guest atau registered + login)
CREATE TABLE customers (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    password_hash VARCHAR(255) DEFAULT NULL,
    name VARCHAR(255) NOT NULL,
    phone VARCHAR(30),
    address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY email (email)
);

-- Pesanan
CREATE TABLE orders (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    order_number VARCHAR(32) NOT NULL UNIQUE,
    customer_id INT UNSIGNED DEFAULT NULL,
    customer_email VARCHAR(255) NOT NULL,
    customer_name VARCHAR(255) NOT NULL,
    customer_phone VARCHAR(30) NOT NULL,
    shipping_address TEXT NOT NULL,
    subtotal DECIMAL(12, 2) NOT NULL,
    shipping_cost DECIMAL(12, 2) NOT NULL DEFAULT 0,
    total DECIMAL(12, 2) NOT NULL,
    status ENUM('pending', 'paid', 'processing', 'shipped', 'delivered', 'cancelled') NOT NULL DEFAULT 'pending',
    payment_method VARCHAR(50) DEFAULT NULL,
    payment_reference VARCHAR(255) DEFAULT NULL,
    snap_token VARCHAR(255) DEFAULT NULL COMMENT 'Token Midtrans Snap',
    payment_proof VARCHAR(255) DEFAULT NULL COMMENT 'Bukti transfer/gambar',
    tracking_number VARCHAR(100) DEFAULT NULL COMMENT 'No. resi pengiriman',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY status (status),
    KEY customer_id (customer_id),
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL
);

-- Detail item pesanan
CREATE TABLE order_items (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    order_id INT UNSIGNED NOT NULL,
    product_id INT UNSIGNED NOT NULL,
    product_name VARCHAR(255) NOT NULL,
    price DECIMAL(12, 2) NOT NULL,
    quantity INT UNSIGNED NOT NULL,
    size VARCHAR(20) DEFAULT NULL,
    subtotal DECIMAL(12, 2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY order_id (order_id),
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE RESTRICT
);

-- Pengaturan website (key-value)
CREATE TABLE settings (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `key` VARCHAR(100) NOT NULL UNIQUE,
    `value` TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Admin users (login dengan email, sama seperti pelanggan)
CREATE TABLE admin_users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    name VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default admin (email=admin@onlineshop.com, password=password)
INSERT INTO admin_users (email, password_hash, name) VALUES
('admin@onlineshop.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Administrator');

-- Insert default settings
INSERT INTO settings (`key`, `value`) VALUES
('store_name', 'ShoeStore'),
('store_description', 'Toko sepatu online terpercaya'),
('store_phone', ''),
('store_address', ''),
('store_logo', ''),
('payment_info', 'Transfer ke BCA 1234567890 a.n. Toko. Konfirmasi via WhatsApp.');

-- Insert sample categories
INSERT INTO categories (name, slug, description) VALUES
('Running', 'running', 'Sepatu lari dan olahraga'),
('Casual', 'casual', 'Sepatu santai sehari-hari'),
('Sneakers', 'sneakers', 'Sepatu sneakers trendy'),
('Formal', 'formal', 'Sepatu formal dan kantor'),
('Sport', 'sport', 'Sepatu untuk berbagai olahraga');

-- Insert sample products
INSERT INTO products (category_id, name, slug, description, price, stock, image, is_active) VALUES
(1, 'Air Runner Pro', 'air-runner-pro', 'Sepatu lari dengan sol bantalan udara untuk kenyamanan maksimal. Cocok untuk marathon dan jogging.', 599000, 50, 'products/air-runner-pro.jpg', 1),
(2, 'Urban Walk Classic', 'urban-walk-classic', 'Sepatu casual nyaman untuk aktivitas sehari-hari. Desain minimalis dan bahan berkualitas.', 449000, 30, 'products/urban-walk.jpg', 1),
(3, 'Street Style Sneakers', 'street-style-sneakers', 'Sneakers dengan desain streetwear. Tersedia berbagai warna.', 529000, 45, 'products/street-sneakers.jpg', 1),
(4, 'Executive Leather', 'executive-leather', 'Sepatu formal kulit asli untuk penampilan profesional di kantor.', 799000, 20, 'products/executive-leather.jpg', 1),
(5, 'Multi Sport Trainer', 'multi-sport-trainer', 'Sepatu serbaguna untuk gym, fitness, dan olahraga ringan.', 479000, 40, 'products/multi-sport.jpg', 1),
(1, 'Marathon Elite', 'marathon-elite', 'Dirancang untuk pelari serius. Ringan dan responsif.', 899000, 25, 'products/marathon-elite.jpg', 1),
(3, 'Retro High Top', 'retro-high-top', 'High top sneakers gaya retro yang kembali populer.', 649000, 35, 'products/retro-high.jpg', 1),
(2, 'Comfort Slip On', 'comfort-slip-on', 'Slip on yang praktis dan nyaman, mudah dipakai kapan saja.', 379000, 60, 'products/slip-on.jpg', 1);
