<?php
/**
 * Redirect ke halaman login tunggal (auth/login.php)
 */
require_once __DIR__ . '/../config/app.php';
header('Location: ' . base_url('auth/login.php'));
exit;
