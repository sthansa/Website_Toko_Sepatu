<?php
require_once __DIR__ . '/../includes/init.php';

if (empty($_SESSION['admin_id'])) {
    header('Location: ' . base_url('auth/login.php'));
    exit;
}

$orderModel = new Order($db);
$orders = $orderModel->getAll();
$statusLabels = [
    'pending' => 'Menunggu Bayar',
    'paid' => 'Dibayar',
    'processing' => 'Diproses',
    'shipped' => 'Dikirim',
    'delivered' => 'Sampai',
    'cancelled' => 'Dibatalkan',
];
$pageTitle = 'Pesanan';
ob_start();
?>
<h1 class="admin-page-title">Manajemen Pesanan</h1>

<div class="card admin-card">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th>No. Pesanan</th>
                    <th>Customer</th>
                    <th>Total</th>
                    <th>Status</th>
                    <th>Tanggal</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($orders as $o): ?>
                <tr>
                    <td class="fw-semibold"><?= e($o['order_number']) ?></td>
                    <td>
                        <?= e($o['customer_name']) ?>
                        <br><small class="text-muted"><?= e($o['customer_email']) ?></small>
                    </td>
                    <td><?= format_rupiah((float)$o['total']) ?></td>
                    <td><span class="badge badge-status-<?= e($o['status']) ?>"><?= $statusLabels[$o['status']] ?? $o['status'] ?></span></td>
                    <td class="text-muted small"><?= date('d M Y H:i', strtotime($o['created_at'])) ?></td>
                    <td>
                        <div class="d-flex gap-1 justify-content-end">
                            <a href="order-detail.php?id=<?= (int)$o['id'] ?>" class="btn btn-sm btn-outline-primary">Detail</a>
                            <form method="post" action="order-delete.php" onsubmit="return confirm('Yakin ingin menghapus pesanan ini?');">
                                <input type="hidden" name="id" value="<?= (int)$o['id'] ?>">
                                <button type="submit" class="btn btn-sm btn-outline-danger">Hapus</button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php if (empty($orders)): ?>
    <div class="card-body text-center text-muted py-4">Belum ada pesanan.</div>
    <?php endif; ?>
</div>
<?php
$adminContent = ob_get_clean();
include __DIR__ . '/layout.php';
?>
