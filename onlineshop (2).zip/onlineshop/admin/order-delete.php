<?php
require_once __DIR__ . '/../includes/init.php';

if (empty($_SESSION['admin_id'])) {
    header('Location: ' . base_url('auth/login.php'));
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    if ($id) {
        $orderModel = new Order($db);
        try {
            $orderModel->delete($id);
            flash('success', 'Pesanan berhasil dihapus.');
        } catch (Exception $e) {
            flash('error', 'Gagal menghapus pesanan karena error sistem.');
        }
    }
}
redirect(base_url('admin/orders.php'));
