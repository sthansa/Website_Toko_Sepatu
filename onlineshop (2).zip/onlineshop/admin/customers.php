<?php
require_once __DIR__ . '/../includes/init.php';

if (empty($_SESSION['admin_id'])) {
    header('Location: ' . base_url('auth/login.php'));
    exit;
}

$stmt = $db->query('SELECT c.*, (SELECT COUNT(*) FROM orders o WHERE o.customer_email = c.email) AS order_count FROM customers c ORDER BY c.created_at DESC');
$customers = $stmt->fetchAll();
$pageTitle = 'Pelanggan';
ob_start();
?>
<h1 class="admin-page-title">Manajemen Pelanggan</h1>

<div class="card admin-card">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Telepon</th>
                    <th>Pesanan</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($customers as $c): ?>
                <tr>
                    <td class="fw-semibold"><?= e($c['name']) ?></td>
                    <td><?= e($c['email']) ?></td>
                    <td><?= e($c['phone'] ?? '-') ?></td>
                    <td><?= (int)$c['order_count'] ?> pesanan</td>
                    <td><a href="customer-detail.php?email=<?= urlencode($c['email']) ?>" class="btn btn-sm btn-outline-primary">Detail</a></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php if (empty($customers)): ?>
    <div class="card-body text-center text-muted py-4">Belum ada data pelanggan.</div>
    <?php endif; ?>
</div>
<?php
$adminContent = ob_get_clean();
include __DIR__ . '/layout.php';
?>
