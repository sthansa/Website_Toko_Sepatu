<?php
require_once __DIR__ . '/../includes/init.php';

if (empty($_SESSION['admin_id'])) {
    header('Location: ' . base_url('auth/login.php'));
    exit;
}

$adminModel = new AdminUser($db);
$admins = $adminModel->getAll();
$pageTitle = 'Manajemen Admin';
ob_start();
?>
<?php if (!empty($_GET['created'])): ?><div class="alert alert-success">Admin berhasil ditambahkan.</div><?php endif; ?>
<?php if (!empty($_GET['updated'])): ?><div class="alert alert-success">Admin berhasil diubah.</div><?php endif; ?>
<?php if (!empty($_GET['deleted'])): ?><div class="alert alert-success">Admin berhasil dihapus.</div><?php endif; ?>
<?php if (!empty($_GET['error']) && $_GET['error'] === 'last_admin'): ?><div class="alert alert-warning">Tidak dapat menghapus satu-satunya admin.</div><?php endif; ?>
<h1 class="admin-page-title d-flex justify-content-between align-items-center flex-wrap gap-2">
    <span>Manajemen Admin</span>
    <a href="admin-form.php" class="btn btn-primary btn-sm"><i class="bi bi-plus-lg me-1"></i>Tambah Admin</a>
</h1>

<div class="card admin-card">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th>Nama</th>
                    <th>Email</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($admins as $a): ?>
                <tr>
                    <td class="fw-semibold"><?= e($a['name']) ?></td>
                    <td><?= e($a['email']) ?></td>
                    <td>
                        <a href="admin-form.php?id=<?= (int)$a['id'] ?>" class="btn btn-sm btn-outline-primary">Edit</a>
                        <?php if ((int)$a['id'] !== (int)($_SESSION['admin_id'] ?? 0)): ?>
                        <a href="admin-delete.php?id=<?= (int)$a['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Hapus admin ini?')">Hapus</a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php
$adminContent = ob_get_clean();
include __DIR__ . '/layout.php';
?>
