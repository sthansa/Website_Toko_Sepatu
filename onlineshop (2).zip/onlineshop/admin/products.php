<?php
require_once __DIR__ . '/../includes/init.php';

if (empty($_SESSION['admin_id'])) {
    header('Location: ' . base_url('auth/login.php'));
    exit;
}

$productModel = new Product($db);
$products = $productModel->getAll(false);
$pageTitle = 'Produk';
ob_start();
?>
<h1 class="admin-page-title d-flex justify-content-between align-items-center flex-wrap gap-2">
    <span>Kelola Produk</span>
    <a href="product-form.php" class="btn btn-primary btn-sm"><i class="bi bi-plus-lg me-1"></i>Tambah Produk</a>
</h1>

<div class="card admin-card">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th>Gambar</th>
                    <th>Nama</th>
                    <th>Kategori</th>
                    <th>Harga</th>
                    <th>Stok</th>
                    <th>Status</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($products as $p): ?>
                <tr>
                    <td>
                        <img src="<?= $p['image'] ? asset_url('images/' . e($p['image'])) : asset_url('images/placeholder.svg') ?>" alt="" style="width:48px;height:48px;object-fit:cover;border-radius:8px;">
                    </td>
                    <td class="fw-semibold"><?= e($p['name']) ?></td>
                    <td><?= e($p['category_name']) ?></td>
                    <td><?= format_rupiah((float)$p['price']) ?></td>
                    <td><?= (int)$p['stock'] ?></td>
                    <td><?= (int)$p['is_active'] ? '<span class="badge bg-success">Aktif</span>' : '<span class="badge bg-secondary">Nonaktif</span>' ?></td>
                    <td>
                        <a href="product-form.php?id=<?= (int)$p['id'] ?>" class="btn btn-sm btn-outline-primary">Edit</a>
                        <a href="product-delete.php?id=<?= (int)$p['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Hapus produk ini?')">Hapus</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php if (empty($products)): ?>
    <div class="card-body text-center text-muted py-4">Belum ada produk. <a href="product-form.php">Tambah produk</a></div>
    <?php endif; ?>
</div>
<?php
$adminContent = ob_get_clean();
include __DIR__ . '/layout.php';
?>
