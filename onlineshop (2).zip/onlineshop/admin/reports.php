<?php
require_once __DIR__ . '/../includes/init.php';

if (empty($_SESSION['admin_id'])) {
    header('Location: ' . base_url('auth/login.php'));
    exit;
}

$month = isset($_GET['month']) ? (int)$_GET['month'] : (int)date('n');
$year = isset($_GET['year']) ? (int)$_GET['year'] : (int)date('Y');

// Total pendapatan (pesanan paid, processing, shipped, delivered)
$stmt = $db->prepare("SELECT COALESCE(SUM(subtotal), 0) AS revenue FROM orders WHERE status IN ('paid','processing','shipped','delivered','completed') AND MONTH(created_at) = ? AND YEAR(created_at) = ?");
$stmt->execute([$month, $year]);
$revenue = (float) $stmt->fetch()['revenue'];

// Jumlah pesanan bulan ini
$stmt = $db->prepare("SELECT COUNT(*) FROM orders WHERE MONTH(created_at) = ? AND YEAR(created_at) = ?");
$stmt->execute([$month, $year]);
$orderCountMonth = (int) $stmt->fetchColumn();

// Produk terlaris (dari order_items)
$stmt = $db->query("
    SELECT oi.product_name, SUM(oi.quantity) AS qty, SUM(oi.subtotal) AS total
    FROM order_items oi
    JOIN orders o ON o.id = oi.order_id
    WHERE o.status IN ('paid','processing','shipped','delivered','completed')
    GROUP BY oi.product_id, oi.product_name
    ORDER BY qty DESC
    LIMIT 10
");
$topProducts = $stmt->fetchAll();



// Data transaksi terperinci bulan dan tahun yang dipilih
$stmt = $db->prepare("
    SELECT o.id, o.order_number, o.customer_name, o.customer_email, o.status, o.created_at, 
           i.product_name, i.quantity, i.price, i.subtotal 
    FROM orders o 
    JOIN order_items i ON o.id = i.order_id 
    WHERE MONTH(o.created_at) = ? AND YEAR(o.created_at) = ?
      AND o.status IN ('paid','processing','shipped','delivered','completed')
    ORDER BY o.created_at DESC
");
$stmt->execute([$month, $year]);
$detailedTransactions = $stmt->fetchAll();

$pageTitle = 'Laporan';
ob_start();
?>
<h1 class="admin-page-title">Laporan Penjualan</h1>

<form method="get" class="row g-2 mb-4">
    <div class="col-auto">
        <select name="month" class="form-select" style="width:auto">
            <?php for ($m = 1; $m <= 12; $m++): ?>
            <option value="<?= $m ?>" <?= $month === $m ? 'selected' : '' ?>><?= date('F', mktime(0,0,0,$m,1,$year)) ?></option>
            <?php endfor; ?>
        </select>
    </div>
    <div class="col-auto">
        <select name="year" class="form-select" style="width:auto">
            <?php for ($y = (int)date('Y'); $y >= (int)date('Y') - 3; $y--): ?>
            <option value="<?= $y ?>" <?= $year === $y ? 'selected' : '' ?>><?= $y ?></option>
            <?php endfor; ?>
        </select>
    </div>
    <div class="col-auto">
        <button type="submit" class="btn btn-primary">Tampilkan</button>
    </div>
</form>

<div class="row g-3 mb-4">
    <div class="col-md-6">
        <div class="card admin-card text-white" style="background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);">
            <div class="card-body position-relative overflow-hidden">
                <i class="bi bi-wallet2 position-absolute" style="font-size:5rem; opacity:0.1; right:-10px; bottom:-15px;"></i>
                <p class="stat-label mb-1 text-light">Total Pendapatan (<?= date('F Y', mktime(0,0,0,$month,1,$year)) ?>)</p>
                <p class="stat-value mb-0 text-white"><?= format_rupiah($revenue) ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card admin-card text-white" style="background: linear-gradient(135deg, #2563eb 0%, #3b82f6 100%);">
            <div class="card-body position-relative overflow-hidden">
                <i class="bi bi-cart-check position-absolute" style="font-size:5rem; opacity:0.2; right:-10px; bottom:-15px;"></i>
                <p class="stat-label mb-1 text-light">Jumlah Pesanan (<?= date('F Y', mktime(0,0,0,$month,1,$year)) ?>)</p>
                <p class="stat-value mb-0 text-white"><?= $orderCountMonth ?></p>
            </div>
        </div>
    </div>
</div>

<div class="row mb-5">
    <div class="col-12">
        <div class="card admin-card mb-0">
            <div class="card-header border-bottom">Produk Terlaris</div>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                        <tr>
                            <th>Produk</th>
                            <th class="text-center">Terjual</th>
                            <th class="text-end">Subtotal Pendapatan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($topProducts as $p): ?>
                        <tr>
                            <td class="fw-semibold text-dark"><?= e($p['product_name']) ?></td>
                            <td class="text-center"><?= (int)$p['qty'] ?></td>
                            <td class="text-end fw-semibold" style="white-space: nowrap;"><?= format_rupiah((float)$p['total']) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php if (empty($topProducts)): ?>
            <div class="card-body text-center text-muted small py-5">Belum ada data penjualan.</div>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="row mb-4">
    <div class="col-12">
        <div class="card admin-card mb-0">
            <div class="card-header border-bottom">
                Detail Transaksi (Bulan <?= date('F Y', mktime(0,0,0,$month,1,$year)) ?>)
            </div>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                        <tr>
                            <th>Waktu Transaksi</th>
                            <th>No. Pesanan</th>
                            <th>Pembeli (Email)</th>
                            <th>Produk yang Dibeli</th>
                            <th>Harga Satuan</th>
                            <th class="text-center">Qty</th>
                            <th class="text-end">Subtotal</th>
                            <th class="text-center">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($detailedTransactions as $row): ?>
                        <tr>
                            <td class="text-muted small" style="white-space: nowrap;"><?= date('d M Y H:i', strtotime($row['created_at'])) ?></td>
                            <td><a href="order-detail.php?id=<?= (int)$row['id'] ?>" class="text-decoration-none fw-semibold"><?= e($row['order_number']) ?></a></td>
                            <td>
                                <div class="fw-bold text-dark"><?= e($row['customer_name']) ?></div>
                                <div class="small text-muted"><?= e($row['customer_email']) ?></div>
                            </td>
                            <td><?= e($row['product_name']) ?></td>
                            <td style="white-space: nowrap;"><?= format_rupiah((float)$row['price']) ?></td>
                            <td class="text-center"><?= (int)$row['quantity'] ?></td>
                            <td class="text-end fw-semibold" style="white-space: nowrap;"><?= format_rupiah((float)$row['subtotal']) ?></td>
                            <td class="text-center"><span class="badge badge-status-<?= e($row['status']) ?> px-3 py-2"><?= e($row['status']) ?></span></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php if (empty($detailedTransactions)): ?>
            <div class="card-body text-center text-muted py-5">
                <i class="bi bi-inbox fs-1 text-muted opacity-50 d-block mb-3"></i>
                Belum ada data transaksi detail di bulan ini.
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php
$adminContent = ob_get_clean();
include __DIR__ . '/layout.php';
?>
