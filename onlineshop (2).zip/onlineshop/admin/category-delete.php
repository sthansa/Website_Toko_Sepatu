<?php
require_once __DIR__ . '/../includes/init.php';

if (empty($_SESSION['admin_id'])) {
    header('Location: ' . base_url('auth/login.php'));
    exit;
}
$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
if ($id) {
    $stmt = $db->prepare('SELECT COUNT(*) FROM products WHERE category_id = ?');
    $stmt->execute([$id]);
    if ((int) $stmt->fetchColumn() > 0) {
        header('Location: categories.php?error=1'); // ada produk
        exit;
    }
    $categoryModel = new Category($db);
    $categoryModel->delete($id);
}
header('Location: categories.php?deleted=1');
exit;
