<?php
require_once __DIR__ . '/../includes/init.php';

if (empty($_SESSION['admin_id'])) {
    header('Location: ' . base_url('auth/login.php'));
    exit;
}

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
$categoryModel = new Category($db);
$category = $id ? $categoryModel->getById($id) : null;

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    if (!$name) $errors[] = 'Nama wajib diisi.';
    if (empty($errors)) {
        $slug = slugify($name);
        if ($category) {
            $categoryModel->update($id, ['name' => $name, 'slug' => $slug, 'description' => $description]);
            header('Location: categories.php?updated=1');
            exit;
        } else {
            $categoryModel->create(['name' => $name, 'slug' => $slug, 'description' => $description]);
            header('Location: categories.php?created=1');
            exit;
        }
    }
}
$pageTitle = $category ? 'Edit Kategori' : 'Tambah Kategori';
ob_start();
?>
<a href="categories.php" class="btn btn-outline-secondary btn-sm mb-3">&larr; Kembali</a>
<h1 class="admin-page-title"><?= $category ? 'Edit' : 'Tambah' ?> Kategori</h1>

<?php if (!empty($errors)): ?>
<div class="alert alert-danger"><?= implode('<br>', array_map('e', $errors)) ?></div>
<?php endif; ?>

<div class="card admin-card">
    <div class="card-body">
        <form method="post">
            <div class="mb-3">
                <label class="form-label">Nama Kategori *</label>
                <input type="text" name="name" class="form-control" value="<?= e($category['name'] ?? $_POST['name'] ?? '') ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Deskripsi</label>
                <textarea name="description" class="form-control" rows="2"><?= e($category['description'] ?? $_POST['description'] ?? '') ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="categories.php" class="btn btn-outline-secondary">Batal</a>
        </form>
    </div>
</div>
<?php
$adminContent = ob_get_clean();
include __DIR__ . '/layout.php';
?>
