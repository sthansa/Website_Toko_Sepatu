<?php
require_once __DIR__ . '/../includes/init.php';

if (empty($_SESSION['admin_id'])) {
    header('Location: ' . base_url('auth/login.php'));
    exit;
}

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
$adminModel = new AdminUser($db);
$admin = $id ? $adminModel->getById($id) : null;

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $name = trim($_POST['name'] ?? '');
    $password = $_POST['password'] ?? '';
    if (!$email) $errors[] = 'Email wajib diisi.';
    if (!$name) $errors[] = 'Nama wajib diisi.';
    if (!$admin && strlen($password) < 6) $errors[] = 'Password minimal 6 karakter (untuk admin baru).';
    if ($admin && $password && strlen($password) < 6) $errors[] = 'Password minimal 6 karakter.';
    if (empty($errors)) {
        $existing = $adminModel->getByEmail($email);
        if ($existing && (int)($existing['id']) !== $id) {
            $errors[] = 'Email sudah dipakai admin lain.';
        } else {
            if ($admin) {
                $adminModel->update($id, [
                    'email' => $email,
                    'name' => $name,
                    'password' => $password
                ]);
                header('Location: admins.php?updated=1');
                exit;
            } else {
                $adminModel->create(['email' => $email, 'name' => $name, 'password' => $password]);
                header('Location: admins.php?created=1');
                exit;
            }
        }
    }
}
$pageTitle = $admin ? 'Edit Admin' : 'Tambah Admin';
ob_start();
?>
<a href="admins.php" class="btn btn-outline-secondary btn-sm mb-3">&larr; Kembali</a>
<h1 class="admin-page-title"><?= $admin ? 'Edit' : 'Tambah' ?> Admin</h1>

<?php if (!empty($errors)): ?>
<div class="alert alert-danger"><?= implode('<br>', array_map('e', $errors)) ?></div>
<?php endif; ?>

<div class="card admin-card">
    <div class="card-body">
        <form method="post">
            <div class="mb-3">
                <label class="form-label">Email *</label>
                <input type="email" name="email" class="form-control" value="<?= e($admin['email'] ?? $_POST['email'] ?? '') ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Nama *</label>
                <input type="text" name="name" class="form-control" value="<?= e($admin['name'] ?? $_POST['name'] ?? '') ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Password <?= $admin ? '(kosongkan jika tidak diubah)' : '*' ?></label>
                <input type="password" name="password" class="form-control" <?= !$admin ? 'required' : '' ?> minlength="6" placeholder="Min. 6 karakter">
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="admins.php" class="btn btn-outline-secondary">Batal</a>
        </form>
    </div>
</div>
<?php
$adminContent = ob_get_clean();
include __DIR__ . '/layout.php';
?>
