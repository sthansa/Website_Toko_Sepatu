<?php
require_once __DIR__ . '/../includes/init.php';

if (empty($_SESSION['admin_id'])) {
    header('Location: ' . base_url('auth/login.php'));
    exit;
}

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
if (!$id) {
    header('Location: orders.php');
    exit;
}

$orderModel = new Order($db);
$order = $orderModel->getById($id);
if (!$order) {
    header('Location: orders.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $oldStatus = $order['status'];
    
    if (isset($_POST['status'])) {
        $orderModel->updateStatus($id, $_POST['status']);
    }
    if (array_key_exists('tracking_number', $_POST)) {
        $orderModel->updateTrackingNumber($id, trim($_POST['tracking_number'] ?? ''));
    }
    
    // Refresh order data
    $order = $orderModel->getById($id);
}

$statusLabels = [
    'pending' => 'Menunggu Pembayaran',
    'paid' => 'Sudah Dibayar',
    'processing' => 'Diproses',
    'shipped' => 'Dikirim',
    'delivered' => 'Sampai',
    'cancelled' => 'Dibatalkan',
];
$pageTitle = 'Detail Pesanan';
ob_start();
?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <a href="orders.php" class="btn btn-outline-secondary btn-sm">&larr; Kembali</a>
    
    <div class="d-flex gap-2">
        <a href="<?= base_url('invoice.php?order_number=' . urlencode($order['order_number'])) ?>" target="_blank" class="btn btn-sm btn-outline-primary"><i class="bi bi-printer"></i> Cetak Nota</a>
        <form method="post" action="order-delete.php" onsubmit="return confirm('Yakin ingin menghapus pesanan ini secara permanen?');">
            <input type="hidden" name="id" value="<?= (int)$order['id'] ?>">
            <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i> Hapus Pesanan</button>
        </form>
    </div>
</div>
<h1 class="admin-page-title">Pesanan <?= e($order['order_number']) ?></h1>

<div class="row g-3">
    <div class="col-lg-8">
        <div class="card admin-card">
            <div class="card-header">Item</div>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                        <tr><th>Produk</th><th>Harga</th><th>Qty</th><th class="text-end">Subtotal</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($order['items'] as $item): ?>
                        <tr>
                            <td><?= e($item['product_name']) ?></td>
                            <td><?= format_rupiah((float)$item['price']) ?></td>
                            <td><?= (int)$item['quantity'] ?></td>
                            <td class="text-end"><?= format_rupiah((float)$item['subtotal']) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="card admin-card">
            <div class="card-header">Alamat Pengiriman</div>
            <div class="card-body">
                <p class="mb-1"><strong><?= e($order['customer_name']) ?></strong></p>
                <p class="mb-1"><?= e($order['customer_phone']) ?></p>
                <p class="mb-0 text-muted"><?= nl2br(e($order['shipping_address'])) ?></p>
                <?php if (!empty($order['notes'])): ?>
                <hr><p class="mb-0"><strong>Catatan:</strong> <?= e($order['notes']) ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card admin-card">
            <div class="card-body">
                <p class="d-flex justify-content-between mb-2"><span>Subtotal</span><span><?= format_rupiah((float)$order['subtotal']) ?></span></p>
                <p class="d-flex justify-content-between mb-2"><span>Ongkir</span><span><?= format_rupiah((float)$order['shipping_cost']) ?></span></p>
                <hr>
                <p class="d-flex justify-content-between fw-bold"><span>Total</span><span><?= format_rupiah((float)$order['total']) ?></span></p>
                <p class="small text-muted mb-0"><?= date('d M Y H:i', strtotime($order['created_at'])) ?></p>
                <?php if (!empty($order['payment_reference'])): ?>
                <hr><p class="small mb-0"><strong>Ref. Pembayaran:</strong> <?= e($order['payment_reference']) ?></p>
                <?php endif; ?>
            </div>
        </div>
        <div class="card admin-card">
            <div class="card-body">
                <form method="post" class="mb-3">
                    <label class="form-label fw-semibold">Ubah Status</label>
                    <div class="d-flex gap-2 flex-wrap">
                        <select name="status" class="form-select flex-grow-1" style="min-width:180px">
                            <?php foreach ($statusLabels as $val => $label): ?>
                            <option value="<?= e($val) ?>" <?= $order['status'] === $val ? 'selected' : '' ?>><?= e($label) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </form>
                <?php if ($order['status'] === 'pending'): ?>
                <form method="post" class="mb-3">
                    <input type="hidden" name="status" value="paid">
                    <button type="submit" class="btn btn-success w-100"><i class="bi bi-check-circle me-1"></i>Konfirmasi Pembayaran (Manual)</button>
                </form>
                <?php endif; ?>

                <?php if (in_array($order['status'], ['paid', 'processing'])): ?>
                <form method="post" class="mb-3">
                    <input type="hidden" name="status" value="shipped">
                    <label class="form-label fw-semibold text-primary">Kirim Pesanan (Input Resi)</label>
                    <div class="d-flex gap-2">
                        <input type="text" name="tracking_number" class="form-control border-primary" value="<?= e($order['tracking_number'] ?? '') ?>" placeholder="Input No. Resi (JNE/Sicepat/dll)..." required>
                        <button type="submit" class="btn btn-primary"><i class="bi bi-truck me-1"></i>Kirim</button>
                    </div>
                </form>
                <?php else: ?>
                <form method="post" class="mb-3">
                    <label class="form-label fw-semibold">No. Resi / Tracking</label>
                    <div class="d-flex gap-2">
                        <input type="text" name="tracking_number" class="form-control" value="<?= e($order['tracking_number'] ?? '') ?>" placeholder="JNE / J&T / POS...">
                        <button type="submit" class="btn btn-outline-secondary">Simpan Resi</button>
                    </div>
                </form>
                <?php endif; ?>

                <?php if ($order['status'] === 'shipped'): ?>
                <form method="post" class="mb-3">
                    <input type="hidden" name="status" value="delivered">
                    <button type="submit" class="btn btn-success w-100" onclick="return confirm('Tandai pesanan ini sebagai telah diterima?');"><i class="bi bi-box-seam me-1"></i>Pesanan Diterima</button>
                </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php
$adminContent = ob_get_clean();
include __DIR__ . '/layout.php';
?>
