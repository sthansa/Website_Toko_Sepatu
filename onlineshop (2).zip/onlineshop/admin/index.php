<?php
require_once __DIR__ . '/../includes/init.php';

if (empty($_SESSION['admin_id'])) {
    header('Location: ' . base_url('auth/login.php'));
    exit;
}

$orderModel = new Order($db);
$productModel = new Product($db);
$customerModel = new Customer($db);
$orders = $orderModel->getAll();
$detailedReport = $orderModel->getDetailedReport(50);
$products = $productModel->getAll(false);
$totalOrders = count($orders);
$totalProducts = count($products);
$totalCustomers = $customerModel->getTotalCount();
$pendingOrders = count(array_filter($orders, fn($o) => $o['status'] === 'pending'));
$revenueThisMonth = 0;
foreach ($orders as $o) {
    if (date('Y-m', strtotime($o['created_at'])) === date('Y-m') && in_array($o['status'], ['paid', 'processing', 'shipped', 'delivered', 'completed'], true)) {
        $revenueThisMonth += (float) $o['subtotal'];
    }
}

$pageTitle = 'Dashboard';
ob_start();
?>
<div class="row g-4 mb-4">
    <!-- Earning Card (Dark) -->
    <div class="col-sm-6 col-lg-3">
        <div class="mockup-card dark">
            <div class="card-top">
                <span class="card-label">Pendapatan Bersih</span>
                <span class="card-icon"><i class="bi bi-currency-dollar"></i></span>
            </div>
            <p class="card-value fs-4 mt-2"><?= format_rupiah($revenueThisMonth) ?></p>
        </div>
    </div>
    
    <!-- Total Orders (Like Share card) -->
    <div class="col-sm-6 col-lg-3">
        <div class="mockup-card">
            <div class="card-top">
                <span class="card-label">Total Pesanan</span>
                <span class="card-icon"><i class="bi bi-share-fill"></i></span>
            </div>
            <p class="card-value mt-2"><?= $totalOrders ?></p>
        </div>
    </div>
    
    <!-- Total Products (Like Likes card) -->
    <div class="col-sm-6 col-lg-3">
        <div class="mockup-card">
            <div class="card-top">
                <span class="card-label">Total Produk</span>
                <span class="card-icon"><i class="bi bi-hand-thumbs-up-fill"></i></span>
            </div>
            <p class="card-value mt-2"><?= $totalProducts ?></p>
        </div>
    </div>
    
    <!-- Total Customers (Like Rating card) -->
    <div class="col-sm-6 col-lg-3">
        <div class="mockup-card">
            <div class="card-top">
                <span class="card-label">Pelanggan</span>
                <span class="card-icon"><i class="bi bi-star-fill"></i></span>
            </div>
            <p class="card-value mt-2"><?= $totalCustomers ?></p>
        </div>
    </div>
</div>

<div class="card admin-card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <span>Laporan Detail Penjualan Terbaru</span>
        <a href="reports.php" class="btn btn-sm btn-outline-primary">Lihat Semua Laporan</a>
    </div>
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th>Tanggal</th>
                    <th>No. Pesanan</th>
                    <th>Pembeli (Email)</th>
                    <th>Produk yang Dibeli</th>
                    <th>Qty</th>
                    <th>Subtotal</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($detailedReport as $row): ?>
                <tr>
                    <td class="text-muted small"><?= date('d/m/Y H:i', strtotime($row['created_at'])) ?></td>
                    <td><a href="order-detail.php?id=<?= (int)$row['id'] ?>" class="text-decoration-none fw-semibold"><?= e($row['order_number']) ?></a></td>
                    <td>
                        <div class="fw-bold"><?= e($row['customer_name']) ?></div>
                        <div class="small text-muted"><?= e($row['customer_email']) ?></div>
                    </td>
                    <td><?= e($row['product_name']) ?></td>
                    <td><?= (int)$row['quantity'] ?></td>
                    <td><?= format_rupiah((float)$row['subtotal']) ?></td>
                    <td><span class="badge badge-status-<?= e($row['status']) ?>"><?= e($row['status']) ?></span></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php if (empty($detailedReport)): ?>
    <div class="card-body text-center text-muted py-4">Belum ada data penjualan.</div>
    <?php endif; ?>
</div>
<?php
$adminContent = ob_get_clean();
include __DIR__ . '/layout.php';
?>
