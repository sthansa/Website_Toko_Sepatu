<?php
require_once __DIR__ . '/../includes/init.php';

if (empty($_SESSION['admin_id'])) {
    header('Location: ' . base_url('auth/login.php'));
    exit;
}

$email = trim($_GET['email'] ?? '');
if (!$email) {
    header('Location: customers.php');
    exit;
}

$customerModel = new Customer($db);
$orderModel = new Order($db);
$customer = $customerModel->getByEmail($email);
if (!$customer) {
    header('Location: customers.php');
    exit;
}
$orders = $orderModel->getByEmail($email);
$statusLabels = ['pending' => 'Menunggu', 'paid' => 'Dibayar', 'processing' => 'Diproses', 'shipped' => 'Dikirim', 'delivered' => 'Sampai', 'cancelled' => 'Batal'];
$pageTitle = 'Detail Pelanggan';
ob_start();
?>
<a href="customers.php" class="btn btn-outline-secondary btn-sm mb-3">&larr; Kembali</a>
<h1 class="admin-page-title"><?= e($customer['name']) ?></h1>

<div class="row g-3">
    <div class="col-md-4">
        <div class="card admin-card">
            <div class="card-header">Data Pelanggan</div>
            <div class="card-body">
                <p class="mb-1"><strong>Email:</strong> <?= e($customer['email']) ?></p>
                <p class="mb-1"><strong>Telepon:</strong> <?= e($customer['phone'] ?? '-') ?></p>
                <p class="mb-0"><strong>Alamat:</strong><br><?= nl2br(e($customer['address'] ?? '-')) ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-8">
        <div class="card admin-card">
            <div class="card-header">Riwayat Pembelian</div>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                        <tr>
                            <th>No. Pesanan</th>
                            <th>Tanggal</th>
                            <th>Total</th>
                            <th>Status</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($orders as $o): ?>
                        <tr>
                            <td class="fw-semibold"><?= e($o['order_number']) ?></td>
                            <td><?= date('d M Y H:i', strtotime($o['created_at'])) ?></td>
                            <td><?= format_rupiah((float)$o['total']) ?></td>
                            <td><span class="badge badge-status-<?= e($o['status']) ?>"><?= $statusLabels[$o['status']] ?? $o['status'] ?></span></td>
                            <td><a href="order-detail.php?id=<?= (int)$o['id'] ?>" class="btn btn-sm btn-outline-primary">Detail</a></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php if (empty($orders)): ?>
            <div class="card-body text-center text-muted py-4">Belum ada pesanan.</div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php
$adminContent = ob_get_clean();
include __DIR__ . '/layout.php';
?>
