<?php
require_once __DIR__ . '/../includes/init.php';

if (empty($_SESSION['admin_id'])) {
    header('Location: ' . base_url('auth/login.php'));
    exit;
}

$categoryModel = new Category($db);
$categories = $categoryModel->getAll();
$pageTitle = 'Kategori';
ob_start();
?>
<h1 class="admin-page-title d-flex justify-content-between align-items-center flex-wrap gap-2">
    <span>Manajemen Kategori</span>
    <a href="category-form.php" class="btn btn-primary btn-sm"><i class="bi bi-plus-lg me-1"></i>Tambah Kategori</a>
</h1>

<div class="card admin-card">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nama</th>
                    <th>Slug</th>
                    <th>Deskripsi</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($categories as $c): ?>
                <tr>
                    <td><?= (int)$c['id'] ?></td>
                    <td class="fw-semibold"><?= e($c['name']) ?></td>
                    <td class="text-muted"><?= e($c['slug']) ?></td>
                    <td class="small"><?= e(mb_substr($c['description'] ?? '', 0, 50)) ?><?= mb_strlen($c['description'] ?? '') > 50 ? '…' : '' ?></td>
                    <td>
                        <a href="category-form.php?id=<?= (int)$c['id'] ?>" class="btn btn-sm btn-outline-primary">Edit</a>
                        <a href="category-delete.php?id=<?= (int)$c['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Hapus kategori ini? Produk dengan kategori ini harus diubah dulu.')">Hapus</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php if (empty($categories)): ?>
    <div class="card-body text-center text-muted py-4">Belum ada kategori. <a href="category-form.php">Tambah kategori</a></div>
    <?php endif; ?>
</div>
<?php
$adminContent = ob_get_clean();
include __DIR__ . '/layout.php';
?>
