<?php
require_once __DIR__ . '/../includes/init.php';
session_start();
if (empty($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}
$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
if ($id) {
    $productModel = new Product($db);
    $productModel->delete($id);
}
header('Location: products.php?deleted=1');
exit;
