<?php
require_once __DIR__ . '/../includes/init.php';

if (empty($_SESSION['admin_id'])) {
    header('Location: ' . base_url('auth/login.php'));
    exit;
}

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
$productModel = new Product($db);
$categoryModel = new Category($db);
$categories = $categoryModel->getAll();
$product = $id ? $productModel->getById($id) : null;

$uploadDir = dirname(__DIR__) . '/assets/images/products/';
if (!is_dir($uploadDir)) {
    @mkdir($uploadDir, 0755, true);
}

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $categoryId = (int) ($_POST['category_id'] ?? 0);
    $description = trim($_POST['description'] ?? '');
    $price = (float) ($_POST['price'] ?? 0);
    $stock = (int) ($_POST['stock'] ?? 0);
    $isActive = isset($_POST['is_active']) ? 1 : 0;
    $imagePath = $product['image'] ?? null;

    if (!$name) $errors[] = 'Nama wajib diisi.';
    if (!$categoryId) $errors[] = 'Kategori wajib dipilih.';
    if ($price <= 0) $errors[] = 'Harga harus lebih dari 0.';

    if (!empty($_FILES['image']['name']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'])) {
            $errors[] = 'Gambar harus JPG, PNG, GIF, atau WebP.';
        } else {
            $newName = 'product-' . ($id ?: 'new') . '-' . time() . '.' . $ext;
            if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir . $newName)) {
                $imagePath = 'products/' . $newName;
            }
        }
    }

    if (empty($errors)) {
        $slug = slugify($name);
        if ($product) {
            $productModel->update($id, [
                'category_id' => $categoryId,
                'name' => $name,
                'slug' => $slug,
                'description' => $description,
                'price' => $price,
                'stock' => $stock,
                'image' => $imagePath,
                'is_active' => $isActive,
            ]);
            header('Location: products.php?updated=1');
            exit;
        } else {
            $productModel->create([
                'category_id' => $categoryId,
                'name' => $name,
                'slug' => $slug,
                'description' => $description,
                'price' => $price,
                'stock' => $stock,
                'image' => $imagePath,
                'is_active' => $isActive,
            ]);
            header('Location: products.php?created=1');
            exit;
        }
    }
}
$pageTitle = $product ? 'Edit Produk' : 'Tambah Produk';
ob_start();
?>
<a href="products.php" class="btn btn-outline-secondary btn-sm mb-3">&larr; Kembali</a>
<h1 class="admin-page-title"><?= $product ? 'Edit' : 'Tambah' ?> Produk</h1>

<?php if (!empty($errors)): ?>
<div class="alert alert-danger"><?= implode('<br>', array_map('e', $errors)) ?></div>
<?php endif; ?>

<div class="card admin-card">
    <div class="card-body">
        <form method="post" enctype="multipart/form-data">
            <div class="mb-3">
                <label class="form-label">Gambar Produk</label>
                <?php if (!empty($product['image'])): ?>
                <div class="mb-2">
                    <img src="<?= asset_url('images/' . e($product['image'])) ?>" alt="" style="max-height:120px;border-radius:8px;">
                </div>
                <?php endif; ?>
                <input type="file" name="image" class="form-control" accept="image/*">
                <small class="text-muted">Kosongkan untuk tetap pakai gambar lama. Format: JPG, PNG, GIF, WebP.</small>
            </div>
            <div class="mb-3">
                <label class="form-label">Nama Produk *</label>
                <input type="text" name="name" class="form-control" value="<?= e($product['name'] ?? $_POST['name'] ?? '') ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Kategori *</label>
                <select name="category_id" class="form-select" required>
                    <option value="">Pilih</option>
                    <?php foreach ($categories as $c): ?>
                    <option value="<?= (int)$c['id'] ?>" <?= ($product['category_id'] ?? '') == $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Deskripsi</label>
                <textarea name="description" class="form-control" rows="3"><?= e($product['description'] ?? $_POST['description'] ?? '') ?></textarea>
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Harga (Rp) *</label>
                    <input type="number" name="price" class="form-control" min="0" step="1000" value="<?= e($product['price'] ?? $_POST['price'] ?? '') ?>" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Stok</label>
                    <input type="number" name="stock" class="form-control" min="0" value="<?= e($product['stock'] ?? $_POST['stock'] ?? 0) ?>">
                </div>
            </div>
            <div class="mb-3">
                <div class="form-check">
                    <input type="checkbox" name="is_active" class="form-check-input" id="active" value="1" <?= ($product['is_active'] ?? 1) ? 'checked' : '' ?>>
                    <label class="form-check-label" for="active">Aktif (tampil di katalog)</label>
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="products.php" class="btn btn-outline-secondary">Batal</a>
        </form>
    </div>
</div>
<?php
$adminContent = ob_get_clean();
include __DIR__ . '/layout.php';
?>
