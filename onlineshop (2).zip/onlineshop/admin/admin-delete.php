<?php
require_once __DIR__ . '/../includes/init.php';

if (empty($_SESSION['admin_id'])) {
    header('Location: ' . base_url('auth/login.php'));
    exit;
}
$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
if ($id && $id !== (int)$_SESSION['admin_id']) {
    $adminModel = new AdminUser($db);
    $all = $adminModel->getAll();
    if (count($all) > 1) {
        $adminModel->delete($id);
        header('Location: admins.php?deleted=1');
    } else {
        header('Location: admins.php?error=last_admin');
    }
} else {
    header('Location: admins.php');
}
exit;
