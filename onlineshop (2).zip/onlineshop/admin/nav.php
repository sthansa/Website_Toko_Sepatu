<nav class="admin-nav">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.php"><i class="bi bi-gear-fill me-2"></i><?= e(APP_NAME) ?> Admin</a>
        <div class="d-flex gap-2 flex-wrap">
            <a class="btn btn-outline-light btn-sm" href="<?= base_url() ?>" target="_blank"><i class="bi bi-shop me-1"></i>Lihat Toko</a>
            <a class="btn btn-outline-light btn-sm" href="index.php"><i class="bi bi-grid me-1"></i>Dashboard</a>
            <a class="btn btn-outline-light btn-sm" href="products.php"><i class="bi bi-box-seam me-1"></i>Produk</a>
            <a class="btn btn-outline-light btn-sm" href="orders.php"><i class="bi bi-cart-check me-1"></i>Pesanan</a>
            <a class="btn btn-outline-danger btn-sm" href="logout.php"><i class="bi bi-box-arrow-right me-1"></i>Logout</a>
        </div>
    </div>
</nav>
