<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle ?? 'Admin') ?> - <?= e(APP_NAME) ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="<?= asset_url('css/style.css') ?>" rel="stylesheet">
    <link href="<?= asset_url('css/admin.css') ?>?v=<?= time() ?>" rel="stylesheet">
</head>
<body class="admin-body">
    <div class="admin-wrapper">
        <!-- Sidebar -->
        <aside class="admin-sidebar" id="adminSidebar">
            <div class="sidebar-profile">
                <!-- Using initial of Admin Name for Avatar -->
                <div class="avatar">
                    <i class="bi bi-person"></i>
                </div>
                <h5 class="name"><?= e($_SESSION['admin_name'] ?? 'Admin User') ?></h5>
                <p class="email"><?= e(APP_NAME) ?> System</p>
            </div>
            
            <div class="admin-sidebar-nav">
                <a href="index.php" class="admin-nav-item <?= (basename($_SERVER['PHP_SELF'] ?? '') === 'index.php') ? 'active' : '' ?>">
                    <i class="bi bi-house-door"></i>
                    <span>Dashboard</span>
                </a>
                <a href="categories.php" class="admin-nav-item <?= in_array(basename($_SERVER['PHP_SELF'] ?? ''), ['categories.php', 'category-form.php'], true) ? 'active' : '' ?>">
                    <i class="bi bi-folder2-open"></i>
                    <span>Kategori</span>
                </a>
                <a href="products.php" class="admin-nav-item <?= in_array(basename($_SERVER['PHP_SELF'] ?? ''), ['products.php', 'product-form.php'], true) ? 'active' : '' ?>">
                    <i class="bi bi-box"></i>
                    <span>Produk</span>
                </a>
                <a href="orders.php" class="admin-nav-item <?= in_array(basename($_SERVER['PHP_SELF'] ?? ''), ['orders.php', 'order-detail.php'], true) ? 'active' : '' ?>">
                    <i class="bi bi-cart3"></i>
                    <span>Pesanan</span>
                </a>
                <a href="customers.php" class="admin-nav-item <?= strpos(basename($_SERVER['PHP_SELF'] ?? ''), 'customer') !== false ? 'active' : '' ?>">
                    <i class="bi bi-people"></i>
                    <span>Pelanggan</span>
                </a>
                <a href="reports.php" class="admin-nav-item <?= basename($_SERVER['PHP_SELF'] ?? '') === 'reports.php' ? 'active' : '' ?>">
                    <i class="bi bi-bar-chart"></i>
                    <span>Laporan</span>
                </a>
                <a href="admins.php" class="admin-nav-item <?= in_array(basename($_SERVER['PHP_SELF'] ?? ''), ['admins.php', 'admin-form.php'], true) ? 'active' : '' ?>">
                    <i class="bi bi-gear"></i>
                    <span>Pengaturan Admin</span>
                </a>
                <a href="logout.php" class="admin-nav-item mt-5 text-danger border border-danger border-opacity-25" style="color: #fca5a5 !important;">
                    <i class="bi bi-box-arrow-right"></i>
                    <span>Keluar</span>
                </a>
            </div>
        </aside>

        <!-- Main content -->
        <main class="admin-main">
            <!-- New Top Header (Mobile Toggle + Page Title inside Content) -->
            <div class="main-header">
                <div class="d-flex align-items-center gap-3">
                    <button class="mobile-toggle" type="button" onclick="document.getElementById('adminSidebar').classList.toggle('show')">
                        <i class="bi bi-list"></i>
                    </button>
                    <h1 class="main-title"><?= e($pageTitle ?? 'Dashboard Admin') ?></h1>
                </div>
                <div class="main-header-actions">
                    <a href="<?= base_url() ?>" target="_blank" class="btn btn-sm btn-outline-secondary" style="border-radius: 50px;">
                        <i class="bi bi-box-arrow-up-right me-1"></i> Lihat Toko
                    </a>
                </div>
            </div>

            <?= $adminContent ?? '' ?>
        </main>
    </div>

    <!-- Backdrop for mobile sidebar -->
    <div id="sidebarBackdrop" class="modal-backdrop fade show" style="display: none;" onclick="document.getElementById('adminSidebar').classList.remove('show'); this.style.display='none';"></div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Simple script to handle mobile toggle backdrop
        const toggleBtn = document.querySelector('.mobile-toggle');
        const sidebar = document.getElementById('adminSidebar');
        const backdrop = document.getElementById('sidebarBackdrop');
        if(toggleBtn) {
            toggleBtn.addEventListener('click', function() {
                if(sidebar.classList.contains('show')) {
                    backdrop.style.display = 'block';
                } else {
                    backdrop.style.display = 'none';
                }
            });
        }
    </script>
</body>
</html>
