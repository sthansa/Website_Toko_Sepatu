<?php
session_start();
unset($_SESSION['admin_id'], $_SESSION['admin_name']);
require_once __DIR__ . '/../config/app.php';
header('Location: ' . base_url('auth/login.php'));
exit;
