<?php
require_once __DIR__ . '/includes/init.php';

$orderNumber = trim($_GET['order_number'] ?? '');
if (!$orderNumber) {
    die("No. Pesanan tidak ditemukan.");
}

$orderModel = new Order($db);
$order = $orderModel->getByOrderNumber($orderNumber);

if (!$order) {
    die("Pesanan tidak valid.");
}

$statusLabels = [
    'pending' => 'Belum Dibayar',
    'paid' => 'Lunas',
    'processing' => 'Diproses',
    'shipped' => 'Dikirim',
    'delivered' => 'Telah Diterima',
    'cancelled' => 'Dibatalkan',
];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nota Pesanan - <?= htmlspecialchars($order['order_number']) ?></title>
    <style>
        body { font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; color: #333; margin: 0; padding: 0; background-color: #f8f9fa; }
        .invoice-box { max-width: 800px; margin: 40px auto; padding: 40px; border: 1px solid #eee; box-shadow: 0 0 15px rgba(0, 0, 0, 0.05); background-color: #fff; }
        .invoice-box table { width: 100%; line-height: inherit; text-align: left; border-collapse: collapse; }
        .invoice-box table td { padding: 10px; vertical-align: top; }
        .invoice-box table tr td:nth-child(2), .invoice-box table tr th:nth-child(2), .invoice-box table tr td:nth-child(3), .invoice-box table tr th:nth-child(3), .invoice-box table tr td:nth-child(4), .invoice-box table tr th:nth-child(4) { text-align: right; }
        .invoice-box table tr.top table td.title { font-size: 35px; line-height: 45px; color: #1e293b; font-weight: bold; }
        .invoice-box table tr.information table td { padding-bottom: 40px; }
        .invoice-box table tr.heading th { background: #f8fafc; border-bottom: 2px solid #cbd5e1; font-weight: bold; padding: 12px 10px; }
        .invoice-box table tr.item td { border-bottom: 1px solid #eee; }
        .invoice-box table tr.item.last td { border-bottom: none; }
        .invoice-box table tr.total td { border-top: 2px solid #cbd5e1; font-weight: bold; }
        .badge { display: inline-block; padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: bold; text-transform: uppercase; }
        .badge-paid { background-color: #dcfce7; color: #166534; }
        .badge-pending { background-color: #fef9c3; color: #854d0e; }
        .badge-other { background-color: #e0e7ff; color: #3730a3; }
        
        @media print {
            body { background-color: #fff; margin: 0; padding: 0; }
            .invoice-box { border: none; box-shadow: none; margin: 0; max-width: 100%; padding: 20px; }
            .print-hide { display: none; }
        }
    </style>
</head>
<body onload="window.print()">
    <div class="invoice-box">
        <div class="print-hide" style="text-align: right; margin-bottom: 20px;">
            <button onclick="window.print()" style="padding: 10px 20px; background-color: #1e293b; color: white; border: none; border-radius: 5px; cursor: pointer;">🖨️ Cetak / Simpan PDF</button>
            <button onclick="window.close()" style="padding: 10px 20px; background-color: #64748b; color: white; border: none; border-radius: 5px; cursor: pointer; margin-left: 10px;">❌ Tutup</button>
        </div>

        <table>
            <tr class="top">
                <td colspan="4">
                    <table>
                        <tr>
                            <td class="title"> <?= APP_NAME ?> </td>
                            <td style="text-align: right;">
                                <strong>Nota Penjualan</strong><br>
                                No. Pesanan: <?= htmlspecialchars($order['order_number']) ?><br>
                                Tanggal: <?= date('d M Y, H:i', strtotime($order['created_at'])) ?><br>
                                Status: 
                                <?php
                                    $statusClass = 'badge-other';
                                    if ($order['status'] === 'paid') $statusClass = 'badge-paid';
                                    if ($order['status'] === 'pending') $statusClass = 'badge-pending';
                                ?>
                                <span class="badge <?= $statusClass ?>"><?= $statusLabels[$order['status']] ?? $order['status'] ?></span>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>

            <tr class="information">
                <td colspan="4">
                    <table>
                        <tr>
                            <td>
                                <strong>PENGIRIM:</strong><br>
                                <?= APP_NAME ?><br>
                                Jakarta, Indonesia<br>
                                cs@<?= strtolower(APP_NAME) ?>.com
                            </td>
                            <td style="text-align: right;">
                                <strong>PENERIMA:</strong><br>
                                <?= htmlspecialchars($order['customer_name']) ?><br>
                                <?= htmlspecialchars($order['customer_phone']) ?><br>
                                <?= nl2br(htmlspecialchars($order['shipping_address'])) ?>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            
            <?php if (!empty($order['tracking_number'])): ?>
            <tr>
                <td colspan="4" style="padding-bottom: 20px;">
                    <div style="background-color: #f8fafc; padding: 15px; border: 1px dashed #cbd5e1; display: inline-block;">
                        <strong style="color: #64748b; font-size: 12px; text-transform: uppercase;">Nomor Resi Pengiriman</strong><br>
                        <span style="font-size: 18px; font-weight: bold; letter-spacing: 1px; color: #0f172a;"><?= htmlspecialchars($order['tracking_number']) ?></span>
                    </div>
                </td>
            </tr>
            <?php endif; ?>

            <tr class="heading">
                <th>Nama Produk</th>
                <th style="width: 15%;">Harga</th>
                <th style="width: 10%;">Qty</th>
                <th style="width: 25%;">Subtotal</th>
            </tr>

            <?php foreach ($order['items'] as $index => $item): ?>
            <tr class="item <?= ($index === count($order['items']) - 1) ? 'last' : '' ?>">
                <td><?= htmlspecialchars($item['product_name']) ?></td>
                <td><?= format_rupiah((float)$item['price']) ?></td>
                <td><?= $item['quantity'] ?></td>
                <td><?= format_rupiah((float)$item['subtotal']) ?></td>
            </tr>
            <?php endforeach; ?>

            <tr class="total">
                <td colspan="3">Subtotal Produk</td>
                <td><?= format_rupiah((float)$order['subtotal']) ?></td>
            </tr>
            <tr>
                <td colspan="3" style="text-align: right; padding-top: 5px;">Ongkos Kirim</td>
                <td style="padding-top: 5px;"><?= format_rupiah((float)$order['shipping_cost']) ?></td>
            </tr>
            <tr class="total">
                <td colspan="3" style="font-size: 18px;">TOTAL KESELURUHAN</td>
                <td style="font-size: 18px; color: #1e293b;"><?= format_rupiah((float)$order['total']) ?></td>
            </tr>
        </table>
        
        <?php if (!empty($order['payment_reference'])): ?>
        <div style="margin-top: 30px; font-size: 12px; color: #64748b;">
            Ref. Pembayaran Midtrans: <?= htmlspecialchars($order['payment_reference']) ?>
        </div>
        <?php endif; ?>
        
        <div style="margin-top: 40px; text-align: center; color: #94a3b8; font-size: 13px; border-top: 1px solid #eee; padding-top: 15px;">
            Terima kasih telah berbelanja di <?= APP_NAME ?>. Kepuasan Anda adalah prioritas kami.<br>
            Dokumen ini dihasilkan secara elektronik dan merupakan bukti transaksi yang sah.
        </div>
    </div>
</body>
</html>
