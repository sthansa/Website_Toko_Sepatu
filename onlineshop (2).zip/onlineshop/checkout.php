<?php
require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/payment.php';

// Wajib login sebelum checkout
if (empty($_SESSION['customer_id'])) {
    flash('info', 'Silakan login terlebih dahulu untuk melanjutkan pesanan.');
    redirect(base_url('auth/login.php?redirect=checkout.php'));
}

$cartItems = Cart::get();
if (empty($cartItems)) {
    flash('error', 'Keranjang kosong.');
    redirect(base_url('cart.php'));
}

$productModel = new Product($db);
$cartWithProducts = [];
$subtotal = 0;

foreach ($cartItems as $key => $item) {
    $product = $productModel->getById((int) $item['product_id']);
    if (!$product || (int) $product['stock'] < (int) $item['quantity']) continue;
    $qty = (int) $item['quantity'];
    $price = (float) $product['price'];
    $itemSubtotal = $price * $qty;
    $subtotal += $itemSubtotal;
    $cartWithProducts[$key] = [
        'key' => $key,
        'product' => $product,
        'quantity' => $qty,
        'size' => $item['size'] ?? null,
        'subtotal' => $itemSubtotal,
    ];
}

if (empty($cartWithProducts)) {
    flash('error', 'Keranjang tidak valid atau stok tidak cukup.');
    redirect(base_url('cart.php'));
}

$shippingCost = 15000; // Flat rate
$total = $subtotal + $shippingCost;

// Pre-fill jika pelanggan login
$defaultEmail = $defaultName = $defaultPhone = $defaultAddress = '';
if (!empty($_SESSION['customer_id'])) {
    $customerModel = new Customer($db);
    $customer = $customerModel->getById((int) $_SESSION['customer_id']);
    if ($customer) {
        $defaultEmail = $customer['email'];
        $defaultName = $customer['name'];
        $defaultPhone = $customer['phone'] ?? '';
        $defaultAddress = $customer['address'] ?? '';
    }
}

// Handle form submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $name = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $notes = trim($_POST['notes'] ?? '');
    $paymentMethod = $_POST['payment_method'] ?? 'midtrans';

    $errors = [];
    if (!$email) $errors[] = 'Email wajib diisi.';
    if (!$name) $errors[] = 'Nama wajib diisi.';
    if (!$phone) $errors[] = 'No. HP wajib diisi.';
    if (!$address) $errors[] = 'Alamat pengiriman wajib diisi.';

    if (empty($errors)) {
        $orderNumber = generate_order_number();
        $orderData = [
            'order_number' => $orderNumber,
            'customer_email' => $email,
            'customer_name' => $name,
            'customer_phone' => $phone,
            'shipping_address' => $address,
            'subtotal' => $subtotal,
            'shipping_cost' => $shippingCost,
            'total' => $total,
            'payment_method' => $paymentMethod,
            'notes' => $notes,
            'snap_token' => null,
        ];

        if ($paymentMethod === 'midtrans') {
            try {
                $snapToken = create_midtrans_snap_token($orderData);
                if ($snapToken) {
                    $orderData['snap_token'] = $snapToken;
                } else {
                    $errors[] = 'Gagal membuat token Midtrans (Response kosong).';
                }
            } catch (Exception $e) {
                $errors[] = 'Error Midtrans: ' . $e->getMessage();
            }
        }

        if (empty($errors)) {
            $items = [];
        foreach ($cartWithProducts as $row) {
            $items[] = [
                'product_id' => (int) $row['product']['id'],
                'product_name' => $row['product']['name'],
                'price' => (float) $row['product']['price'],
                'quantity' => $row['quantity'],
                'size' => $row['size'],
                'subtotal' => $row['subtotal'],
            ];
        }
        try {
            $orderModel = new Order($db);
            $orderId = $orderModel->create($orderData, $items);
            // Kurangi stok
            foreach ($items as $item) {
                $productModel->updateStock($item['product_id'], $item['quantity']);
            }
            Cart::clear();
            $_SESSION['last_order_id'] = $orderId;
            $_SESSION['last_order_number'] = $orderNumber;
            redirect(base_url('order-success.php'));
        } catch (Exception $e) {
            $errors[] = 'Gagal membuat pesanan. Silakan coba lagi.';
        }
        }
    }
    if (!empty($errors)) {
        flash_old($_POST);
        foreach ($errors as $err) flash('error', $err);
    }
}

$pageTitle = 'Checkout';
require_once __DIR__ . '/includes/header.php';

$errorMsg = get_flash('error');
?>

<div class="container py-4">
    <h1 class="mb-4 section-title">Checkout</h1>
    <?php if ($errorMsg): ?>
    <div class="alert alert-danger"><?= e($errorMsg) ?></div>
    <?php endif; ?>

    <form method="post" action="">
        <div class="row">
            <div class="col-lg-7">
                <div class="card summary-card mb-4">
                    <div class="card-body">
                        <h5 class="card-title mb-3">Data Pengiriman</h5>
                        <div class="mb-3">
                            <label class="form-label">Email *</label>
                            <input type="email" name="email" class="form-control" value="<?= e(old('email', $_POST['email'] ?? $defaultEmail)) ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Nama Lengkap *</label>
                            <input type="text" name="name" class="form-control" value="<?= e(old('name', $_POST['name'] ?? $defaultName)) ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">No. HP *</label>
                            <input type="tel" name="phone" class="form-control" value="<?= e(old('phone', $_POST['phone'] ?? $defaultPhone)) ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Alamat Pengiriman *</label>
                            <textarea name="address" class="form-control" rows="3" required><?= e(old('address', $_POST['address'] ?? $defaultAddress)) ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Catatan (opsional)</label>
                            <textarea name="notes" class="form-control" rows="2"><?= e(old('notes', $_POST['notes'] ?? '')) ?></textarea>
                        </div>
                    </div>
                </div>
                <div class="card summary-card">
                    <div class="card-body">
                        <h5 class="card-title mb-3">Metode Pembayaran</h5>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="payment_method" id="pm1" value="midtrans" checked>
                            <label class="form-check-label" for="pm1">Pembayaran Online (Midtrans)</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="payment_method" id="pm3" value="cod">
                            <label class="form-check-label" for="pm3">Bayar di Tempat (COD)</label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-5">
                <div class="card summary-card sticky-top">
                    <div class="card-body">
                        <h5 class="card-title mb-3">Ringkasan Pesanan</h5>
                        <ul class="list-unstyled mb-0">
                            <?php foreach ($cartWithProducts as $row): ?>
                            <li class="d-flex justify-content-between py-2 border-bottom">
                                <span><?= e($row['product']['name']) ?> x<?= $row['quantity'] ?></span>
                                <span><?= format_rupiah($row['subtotal']) ?></span>
                            </li>
                            <?php endforeach; ?>
                        </ul>
                        <hr>
                        <p class="d-flex justify-content-between mb-1"><span>Subtotal</span><span><?= format_rupiah($subtotal) ?></span></p>
                        <p class="d-flex justify-content-between mb-1"><span>Ongkir</span><span><?= format_rupiah($shippingCost) ?></span></p>
                        <p class="d-flex justify-content-between fw-bold fs-5 mt-3"><span>Total</span><span><?= format_rupiah($total) ?></span></p>
                        <button type="submit" class="btn btn-primary btn-lg w-100 mt-3">Buat Pesanan</button>
                        <a href="<?= base_url('cart.php') ?>" class="btn btn-outline-primary w-100 mt-2">Kembali ke Keranjang</a>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
