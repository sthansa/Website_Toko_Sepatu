<?php
require_once __DIR__ . '/includes/init.php';

$slug = $_GET['slug'] ?? '';
if (!$slug) {
    redirect(base_url('products.php'));
}

$productModel = new Product($db);
$product = $productModel->getBySlug($slug);
if (!$product) {
    redirect(base_url('products.php'));
}

$pageTitle = $product['name'];
require_once __DIR__ . '/includes/header.php';

$sizes = ['38', '39', '40', '41', '42', '43', '44'];
?>

<div class="container py-4">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url() ?>">Beranda</a></li>
            <li class="breadcrumb-item"><a href="<?= base_url('products.php') ?>">Katalog</a></li>
            <li class="breadcrumb-item active"><?= e($product['name']) ?></li>
        </ol>
    </nav>

    <div class="row g-4">
        <div class="col-lg-5">
            <div class="product-detail-img">
                <img src="<?= $product['image'] ? asset_url('images/' . e($product['image'])) : asset_url('images/placeholder.svg') ?>" alt="<?= e($product['name']) ?>" class="img-fluid">
            </div>
        </div>
        <div class="col-lg-7">
            <span class="badge category-badge mb-2"><?= e($product['category_name']) ?></span>
            <h1 class="section-title mb-3"><?= e($product['name']) ?></h1>
            <p class="fs-4 fw-bold mb-3" style="color:var(--accent)"><?= format_rupiah((float) $product['price']) ?></p>
            <p class="text-muted"><?= nl2br(e($product['description'])) ?></p>

            <?php if ((int) $product['stock'] > 0): ?>
            <form action="<?= base_url('cart-add.php') ?>" method="post" class="mb-4">
                <input type="hidden" name="product_id" value="<?= (int) $product['id'] ?>">
                <div class="mb-3">
                    <label class="form-label">Ukuran</label>
                    <select name="size" class="form-select" style="max-width: 120px;">
                        <option value="">Pilih</option>
                        <?php foreach ($sizes as $s): ?>
                        <option value="<?= e($s) ?>"><?= e($s) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Jumlah</label>
                    <input type="number" name="quantity" value="1" min="1" max="<?= (int) $product['stock'] ?>" class="form-control" style="max-width: 100px;">
                </div>
                <button type="submit" class="btn btn-primary btn-lg">
                    <i class="bi bi-cart-plus me-2"></i>Tambah ke Keranjang
                </button>
            </form>
            <p class="small text-muted">Stok: <?= (int) $product['stock'] ?> tersedia</p>
            <?php else: ?>
            <p class="text-danger fw-bold">Stok habis.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
