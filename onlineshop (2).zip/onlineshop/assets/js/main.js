/**
 * ShoeStore - Main JavaScript
 */
document.addEventListener('DOMContentLoaded', function () {
    // Bootstrap tooltips
    [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]')).forEach(function (el) {
        new bootstrap.Tooltip(el);
    });

    // Quantity inputs in cart
    document.querySelectorAll('.qty-input').forEach(function (input) {
        input.addEventListener('change', function () {
            const form = this.closest('form');
            if (form) form.submit();
        });
    });

    // Confirm delete cart item
    document.querySelectorAll('[data-confirm-remove]').forEach(function (btn) {
        btn.addEventListener('click', function (e) {
            if (!confirm('Hapus item dari keranjang?')) e.preventDefault();
        });
    });
});
