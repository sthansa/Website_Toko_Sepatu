<?php
require_once __DIR__ . '/../includes/init.php';

// Sudah login admin → ke dashboard admin
if (!empty($_SESSION['admin_id'])) {
    redirect(base_url('admin/index.php'));
}
// Sudah login pelanggan → ke dashboard pelanggan (atau ke halaman redirect jika ada)
if (!empty($_SESSION['customer_id'])) {
    $redirectTo = $_GET['redirect'] ?? 'customer/dashboard.php';
    redirect(base_url($redirectTo));
}

$infoMsg = get_flash('info');
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email && $password) {
        // 1. Cek admin (login dengan email)
        $adminModel = new AdminUser($db);
        $admin = $adminModel->getByEmail($email);
        if ($admin && password_verify($password, $admin['password_hash'])) {
            $_SESSION['admin_id'] = (int) $admin['id'];
            $_SESSION['admin_name'] = $admin['name'];
            redirect(base_url('admin/index.php'));
        }

        // 2. Cek pelanggan
        $customerModel = new Customer($db);
        $customer = $customerModel->getByEmail($email);
        if ($customer && !empty($customer['password_hash']) && password_verify($password, $customer['password_hash'])) {
            $_SESSION['customer_id'] = (int) $customer['id'];
            $_SESSION['customer_name'] = $customer['name'];
            
            $redirectTo = $_GET['redirect'] ?? 'customer/dashboard.php';
            redirect(base_url($redirectTo));
        }
    }
    $error = 'Email atau password salah.';
}
$pageTitle = 'Login';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle) ?> - <?= e(APP_NAME) ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="<?= asset_url('css/style.css') ?>" rel="stylesheet">
</head>
<body class="auth-page">
    <div class="auth-wrapper">
        <div class="auth-card">
            <div class="auth-header">
                <a href="<?= base_url() ?>" class="auth-logo"><i class="bi bi-shoe-sneaker"></i> <?= e(APP_NAME) ?></a>
                <h1 class="auth-title">Masuk</h1>
                <p class="auth-subtitle">Gunakan email dan password Anda. Sistem akan mengarahkan ke dashboard sesuai role (admin atau pelanggan).</p>
            </div>
            <?php if ($infoMsg): ?>
            <div class="alert alert-info"><?= e($infoMsg) ?></div>
            <?php endif; ?>
            <?php if ($error): ?>
            <div class="alert alert-danger"><?= e($error) ?></div>
            <?php endif; ?>
            <form method="post" class="auth-form">
                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-envelope"></i></span>
                        <input type="email" name="email" class="form-control" required autofocus value="<?= e($_POST['email'] ?? '') ?>" placeholder="contoh@email.com">
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Password</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-lock"></i></span>
                        <input type="password" name="password" class="form-control" required placeholder="••••••••">
                    </div>
                </div>
                <button type="submit" class="btn btn-primary btn-lg w-100 mb-3">Masuk</button>
                <p class="text-center text-muted small mb-0">Belum punya akun pelanggan? <a href="<?= base_url('auth/register.php' . (!empty($_GET['redirect']) ? '?redirect=' . urlencode($_GET['redirect']) : '')) ?>">Daftar sekarang</a></p>
            </form>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
