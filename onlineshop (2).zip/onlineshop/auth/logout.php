<?php
require_once __DIR__ . '/../config/app.php';
session_start();
unset($_SESSION['customer_id'], $_SESSION['customer_name']);
header('Location: ' . base_url());
exit;
