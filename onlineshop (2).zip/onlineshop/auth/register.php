<?php
require_once __DIR__ . '/../includes/init.php';

if (!empty($_SESSION['customer_id'])) {
    $redirectTo = $_GET['redirect'] ?? 'customer/dashboard.php';
    redirect(base_url($redirectTo));
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $name = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['password_confirm'] ?? '';

    if (!$email) $error = 'Email wajib diisi.';
    elseif (!$name) $error = 'Nama wajib diisi.';
    elseif (strlen($password) < 6) $error = 'Password minimal 6 karakter.';
    elseif ($password !== $confirm) $error = 'Konfirmasi password tidak cocok.';
    else {
        $customerModel = new Customer($db);
        if ($customerModel->getByEmail($email)) {
            $error = 'Email sudah terdaftar.';
        } else {
            $customerModel->create([
                'email' => $email,
                'password_hash' => password_hash($password, PASSWORD_DEFAULT),
                'name' => $name,
                'phone' => $phone,
                'address' => $address
            ]);
            $customer = $customerModel->getByEmail($email);
            $_SESSION['customer_id'] = (int) $customer['id'];
            $_SESSION['customer_name'] = $customer['name'];
            
            $redirectTo = $_GET['redirect'] ?? 'customer/dashboard.php';
            redirect(base_url($redirectTo));
        }
    }
}
$pageTitle = 'Daftar Akun';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle) ?> - <?= e(APP_NAME) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="<?= asset_url('css/style.css') ?>" rel="stylesheet">
</head>
<body class="auth-page">
    <div class="auth-wrapper">
        <div class="auth-card">
            <div class="auth-header">
                <a href="<?= base_url() ?>" class="auth-logo"><i class="bi bi-shop"></i> <?= e(APP_NAME) ?></a>
                <h1 class="auth-title">Buat Akun</h1>
                <p class="auth-subtitle">Daftar untuk memudahkan pesanan dan lacak pengiriman.</p>
            </div>
            <?php if ($error): ?>
            <div class="alert alert-danger"><?= e($error) ?></div>
            <?php endif; ?>
            <form method="post" class="auth-form">
                <div class="mb-3">
                    <label class="form-label">Nama Lengkap *</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-person"></i></span>
                        <input type="text" name="name" class="form-control" required value="<?= e($_POST['name'] ?? '') ?>">
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Email *</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-envelope"></i></span>
                        <input type="email" name="email" class="form-control" required value="<?= e($_POST['email'] ?? '') ?>">
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">No. HP</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-telephone"></i></span>
                        <input type="tel" name="phone" class="form-control" value="<?= e($_POST['phone'] ?? '') ?>">
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Alamat</label>
                    <textarea name="address" class="form-control" rows="2"><?= e($_POST['address'] ?? '') ?></textarea>
                </div>
                <div class="mb-3">
                    <label class="form-label">Password * (minimal 6 karakter)</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-lock"></i></span>
                        <input type="password" name="password" class="form-control" required>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Konfirmasi Password *</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-lock-fill"></i></span>
                        <input type="password" name="password_confirm" class="form-control" required>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary btn-lg w-100 mb-3">Daftar</button>
                <p class="text-center text-muted small mb-0">Sudah punya akun? <a href="<?= base_url('auth/login.php' . (!empty($_GET['redirect']) ? '?redirect=' . urlencode($_GET['redirect']) : '')) ?>">Masuk</a></p>
            </form>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
